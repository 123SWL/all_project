test <- read.table("C:/Users/juanj/Desktop/HRD2/HRD/gw_wgs2/06_07/hatchet/best.bbc.ucn",sep="\t")
library(tidyverse)
test_1 <- separate(data = test, col = V14, into = c("V14_1","V14_2"), sep = "\\|")
print(test_1)
test_1 <- test_1[,c(4,1:3,1,14,14,15,1,1)]
colnames(test_1)<-c("sampleID" ,"chromosome"  ,"start_position"  ,"end_position","Nprobes","total_cn" , "A_cn",  "B_cn" ,"ploidy" ,"contamination")
test_1$Nprobes <- 1
test_1$total_cn <- as.numeric(test_1$A_cn) + as.numeric(test_1$B_cn)
test_1$ploidy <- 1
test_1$contamination <- 1

write.csv(test_1,"C:/Users/juanj/Desktop/HRD2/HRD/gw_wgs2/06_07/hatchet/best.bbc.ucn.csv",quote = FALSE)
