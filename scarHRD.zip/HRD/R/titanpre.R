a <- read.table("D:/gw_wgs2/06_07/titan/snakemake/results/titan/hmm/optimalClusterSolution.txt",sep="\t",header =T )
a1 <- a[,c("norm","ploidy")]
a2 <- a[,c("id","path")]
library(tidyverse)
a2 <- separate(a2,path,c("path1","path2"),sep="//")
a2 <- separate(a2,path1,c("path1_1","path1_2","path1_3","path1_4"),sep="/")
b <- read.table(paste0("D:/gw_wgs2/06_07/titan/snakemake/results/titan/hmm/",a2$path1_4,"/tumor_sample_1_cluster1.segs.txt"),sep="\t",header = F)
library(tidyverse)
test_1 <- b[,c(1:4,1,10:12,1,1)]
#'print(test_1)
test_1<-test_1[-1,]

colnames(test_1)<-c("sampleID" ,"chromosome"  ,"start_position"  ,"end_position","Nprobes","total_cn" , "A_cn",  "B_cn" ,"ploidy" ,"contamination")
test_1$Nprobes <- 1
#'test_1$total_cn <- as.numeric(test_1$A_cn) + as.numeric(test_1$B_cn)
test_1$ploidy <- a1[1,1]
test_1$contamination <-a1[1,2]


write.csv(test_1,"D:/gw_wgs2/06_07/titan/snakemake/results/titan/hmm/best.txt",quote = FALSE)




