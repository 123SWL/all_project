data <- read.csv("D:/gw_wgs2/06_07/hatchet/ploidy.log",sep = "\t",header = F)
library(tidyverse)
a <-separate(data,"V1",into =c("1","2","3","4") ,sep="--")
a1 <- as.data.frame(t(a[6,2:3]))

a2 <- separate(a1,"6",into =c("class","Value") ,sep=":")
row.names(a2) <- a2[,1]
a2 <- as.data.frame(t(a2))
a2 <- a2[-1,]

test <- read.table("D:/gw_wgs2/06_07/hatchet/best.bbc.ucn",sep="\t")
library(tidyverse)
test_1 <- separate(data = test, col = V14, into = c("V14_1","V14_2"), sep = "\\|")
test_1 <- test_1[,c(4,1:3,1,14,14,15,1,1)]
colnames(test_1)<-c("sampleID" ,"chromosome"  ,"start_position"  ,"end_position","Nprobes","total_cn" , "A_cn",  "B_cn" ,"ploidy" ,"contamination")
test_1$Nprobes <- 1
test_1$total_cn <- as.numeric(test_1$A_cn) + as.numeric(test_1$B_cn)
test_1$ploidy <- a2[1,2]
test_1$contamination <-a2[1,1]

write.csv(test_1,"D:/gw_wgs2/06_07/hatchet/best.txt",quote = FALSE)


