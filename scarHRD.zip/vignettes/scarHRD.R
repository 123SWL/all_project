## ----part1, echo=TRUE, eval=FALSE----------------------------------------
#  library(devtools)
#  install_github('sztup/scarHRD',build_vignettes = TRUE)

## ----part2, echo=TRUE, eval=FALSE----------------------------------------
#  getwd()

