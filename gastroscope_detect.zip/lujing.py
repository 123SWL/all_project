import os
paths= "/public/data/shaojuanjuan/yolov5/JPG/"
f=open('test.txt', 'w')
filenames=os.listdir(paths)
filenames.sort()
for filename in filenames:
 
    out_path="/public/data/shaojuanjuan/yolov5/paper_data/JPG/" + filename
    print(out_path)
    f.write(out_path+'\n')
f.close()
