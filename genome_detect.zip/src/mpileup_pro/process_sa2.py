import pysam
from tag_func import *
from BFS import GraphTraverser
import logging
import matplotlib.pyplot as mpl


def plot_alns(PLOT_STUFF, report_dir, aln_graph, current_ind):
    if PLOT_STUFF:
        PLOT_DIR = report_dir + 'alignments/'
        fig = mpl.figure(0, figsize=(14, 6))
        mpl.subplot(121)
        #plt.figure()
        # mpl.rcParams['font.family'] = ['serif']
        # mpl.rcParams['font.serif'] = ['Times New Roman'] + mpl.rcParams['font.serif']
        # mpl.rcParams['font.size'] = 10
        # ax = mpl.axes()
        for node in aln_graph.keys():
            (q_s, q_e, r_s, r_e, is_rev) = aln_graph[node][0]
            if is_rev:
                y = [q_s, q_e]
            else:
                y = [q_e, q_s]
            x = [r_s, r_e]
            mpl.plot(x, y, '-k', linewidth=2)
        mpl.grid()
        # mpl.xlabel('ref position')
        # mpl.ylabel('read position')

        ax = mpl.gca()
        ax.invert_yaxis()
        secax = ax.secondary_xaxis('top')
        secax.set_xticks([])
        secax.spines['top'].set_visible(False)
        ax.xaxis.set_ticks_position('top')
        ax.yaxis.set_ticks_position('left')
        ax.spines['right'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        # secax.set_xlabel('REF')
        # ax.set_ylabel('READ')

        # mpl.subplot(122)
        # mpl.grid()
        # for i in range(len(bestPath)):
        #     (qs, qf, ss, sf) = node_dat[bestPath[i]]
        #     print("pic 2:", (qs, qf, ss, sf))
        #     x = [ss, sf]
        #     y = [qs, qf]
        #     mpl.xlabel('ref position')
        #     mpl.ylabel('read position')
        #     mpl.plot(x, y, '-k', linewidth=2)

        # mpl.xlim([0, sLen])
        # mpl.show()
        mpl.savefig(PLOT_DIR + 'read_' + str(current_ind - 1) + '.pdf')
        # mpl.clf()
        mpl.close(fig)


def get_sa_alignment(bam, main_alignment, read_name_list):
    """Reconstruct other alignments of the same read for a given alignment from the SA tag"""
    if main_alignment.get_cigar_stats()[0][5] > 0:
        return []
    try:
        sa_tag = main_alignment.get_tag("SA").split(";")
    except KeyError:
        return []
    other_alignments = []
    # For each other alignment encoded in the SA tag
    for element in sa_tag:
        # Read information from the tag
        if element == "":
            continue
        fields = element.split(",")
        if len(fields) != 6:
            logging.warning(
                'SA tag does not consist of 6 fields. This could be a sign of invalid characters (e.g. commas or semicolons) in a chromosome name of the reference genome.')
            continue
        rname = fields[0]
        # remove alignment like: chrUn_JTFH01000734v1_decoy
        if rname not in read_name_list:
            continue
        pos = int(fields[1])
        strand = fields[2]
        # CIGAR string encoded in SA tag is shortened
        cigar = fields[3]
        mapq = int(fields[4])
        nm = int(fields[5])

        # Generate an aligned segment from the information
        a = pysam.AlignedSegment()
        a.query_name = main_alignment.query_name
        a.query_sequence = main_alignment.query_sequence
        if strand == "+":
            a.flag = 2048
        else:
            a.flag = 2064
        a.reference_id = bam.get_tid(rname)
        a.reference_start = pos - 1
        try:
            a.mapping_quality = mapq
        except OverflowError:
            a.mapping_quality = 0
        a.cigarstring = cigar
        a.next_reference_id = -1
        a.next_reference_start = -1
        a.template_length = 0
        a.query_qualities = main_alignment.query_qualities
        a.set_tags([("NM", nm, "i")])

        other_alignments.append(a)
    return other_alignments


def adjust_supp_direction(suppls, primary):
    prim_forward = primary.is_reverse
    query_list = []
    alignments = [primary] + suppls
    for alignment in alignments:
        is_reverse = alignment.is_reverse
        infer_len = alignment.infer_read_length()
        if prim_forward != is_reverse:
            q_start = infer_len - alignment.query_alignment_end
            q_end = infer_len - alignment.query_alignment_start
        else:
            q_start = alignment.query_alignment_start
            q_end = alignment.query_alignment_end
        if alignment.is_reverse != prim_forward:
            is_reverse = False
        else:
            is_reverse = True
        ref_id = alignment.reference_id
        r_start = alignment.reference_start
        r_end = alignment.reference_end
        query_list.append((q_start, q_end, r_start, r_end, is_reverse, ref_id, primary))
    return query_list


def seperate_aln(aln_list):
    """
    处理相同query name的sub graph情况，把其切割为多个alignment
    :param aln_list:
    :return:
    """
    cut_aln_dict = {}
    node_ind = 0
    sorted_new_aln = sorted(aln_list, key=lambda aln: (aln[0], aln[1]))
    cut_aln_dict[node_ind] = (sorted_new_aln[0])
    for i in range(len(sorted_new_aln) - 1):
        (cur_q_s, cur_q_e, cur_r_s, cur_r_e, cur_is_rev, _, _) = sorted_new_aln[i]
        (next_q_s, next_q_e, next_r_s, next_r_e, next_is_rev, _, _) = sorted_new_aln[i + 1]
        # 判断两个aln存在重叠
        # no overlap on ref
        if max(cur_r_s, next_r_s) >= min(cur_r_e, next_r_e):
            node_ind += 1
            cut_aln_dict[node_ind] = (next_q_s, next_q_e, next_r_s, next_r_e, next_is_rev)
        # aln A is fully covered by aln B or B is covered by A
        # 这里的2表示：阈值，对于ref坐标差1的情况，也认为是fully covered，因为可能和取坐标有关系，还需调整
        elif (cur_r_s + 2 > next_r_s and cur_r_e < next_r_e + 2) or (cur_r_s < next_r_s + 2 and cur_r_e + 2 > next_r_e):
            node_ind += 1
            cut_aln_dict[node_ind] = (next_q_s, next_q_e, next_r_s, next_r_e, next_is_rev)
        # overlap on ref
        else:
            # print("directions:", cur_is_rev, next_is_rev)
            # print("original:", (cur_q_s, cur_q_e, cur_r_s, cur_r_e), (next_q_s, next_q_e, next_r_s, next_r_e))
            # 两条aln同方向
            if cur_is_rev == next_is_rev:
                # cur: +, next: +, 与primary方向一致
                if cur_is_rev:
                    if next_r_e > cur_r_e:
                        # overlap part on next aln
                        node_ind += 1
                        overlap_on_ref = cur_r_e - next_r_s
                        cut_aln_dict[node_ind] = (
                            next_q_s, next_q_s + overlap_on_ref, next_r_s, cur_r_e, next_is_rev)
                        # no overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_s + overlap_on_ref, next_q_e, cur_r_e, next_r_e, next_is_rev)
                    else:
                        overlap_on_ref = next_r_e - cur_r_s
                        # no overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_s, next_q_e - overlap_on_ref, next_r_s, cur_r_s, next_is_rev)
                        # overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_e - overlap_on_ref, next_q_e, cur_r_s, next_r_e, next_is_rev)
                # cur: -, next: -, 与primary方向不一致
                else:
                    if next_r_e > cur_r_e:
                        overlap_on_ref = cur_r_e - next_r_s
                        # no overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_s, next_q_e - overlap_on_ref, cur_r_e, next_r_e, next_is_rev)
                        # overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_e - overlap_on_ref, next_q_e, next_r_s, cur_r_e, next_is_rev)
                    else:
                        # overlap part on next aln
                        node_ind += 1
                        overlap_on_ref = next_r_e - cur_r_s
                        cut_aln_dict[node_ind] = (
                            next_q_s, next_q_s + overlap_on_ref, cur_r_s, next_r_e, next_is_rev)
                        # no overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_s + overlap_on_ref, next_q_e, next_r_s, cur_r_s, next_is_rev)
            # 两条aln方向不同
            else:
                # cur: +, next: -
                if cur_is_rev and not next_is_rev:
                    if next_r_e > cur_r_e:
                        overlap_on_ref = cur_r_e - next_r_s
                        # no overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_s, next_q_e - overlap_on_ref, cur_r_e, next_r_e, next_is_rev)
                        # overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_e - overlap_on_ref, next_q_e, next_r_s, cur_r_e, next_is_rev)
                    else:
                        # overlap part on next aln
                        node_ind += 1
                        overlap_on_ref = next_r_e - cur_r_s
                        cut_aln_dict[node_ind] = (
                            next_q_s, next_q_s + overlap_on_ref, cur_r_s, next_r_e, next_is_rev)
                        # no overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_s + overlap_on_ref, next_q_e, next_r_s, cur_r_s, next_is_rev)
                # cur: -, next: +
                else:
                    if next_r_e > cur_r_e:
                        # overlap part on next aln
                        node_ind += 1
                        overlap_on_ref = cur_r_e - next_r_s
                        cut_aln_dict[node_ind] = (
                            next_q_s, next_q_s + overlap_on_ref, next_r_s, cur_r_e, next_is_rev)
                        # no overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_s + overlap_on_ref, next_q_e, cur_r_e, next_r_e, next_is_rev)
                    else:
                        overlap_on_ref = next_r_e - cur_r_s
                        # no overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_s, next_q_e - overlap_on_ref, next_r_s, cur_r_s, next_is_rev)
                        # overlap part on next aln
                        node_ind += 1
                        cut_aln_dict[node_ind] = (
                            next_q_e - overlap_on_ref, next_q_e, cur_r_s, next_r_e, next_is_rev)
    return cut_aln_dict


# 这个函数仅针对某一个query name
def process_sa2(bam, options, fasta_open, suppls, prim, count, plot_it=True):
    # 主要包括以下步骤：
    # 针对某一个query name
    # step1：遍历alignments，切割发生sub dup的alignment，记录成cut_aln[node_ind]=(q_s,q_e,ref_s,ref_e,is_reverse)
    # step2: 按照read坐标排序，将aln抽象为一个node，两两构图，存成alns[node_ind] = (q_s,q_e,ref_s,ref_e,is_reverse),
    #        [node1,node2,...],[(node1,node2),...,(),]三个列表形式
    # step3: 采用BFS算法寻优，返回最优路径及相应坐标信息，dup_aln,inv_aln
    # step4: 对step3输出分析，处理成candiadate region， 以及tag

    tag_sigs_all = {}

    # 获取基本信息，便于后续tag
    q_name = prim.query_name
    # 调整inversion read上的坐标, aln_item = [(q_start, q_end, r_start, r_end, is_reverse, ref_id, prim),...]
    aln_item = adjust_supp_direction(suppls, prim)
    ref_chr = bam.getrname(aln_item[0][5])

    # step1：遍历alignments，切割发生sub dup的alignment, 记录成：cut_alns[node_ind]=(q_s,q_e,ref_s,ref_e,is_reverse)
    cut_alns = seperate_aln(aln_item)

    # step2: 按照read坐标排序，将aln抽象为一个node，两两构图，存成:
    #      aln_graph[node_ind] = [(q_s,q_e,ref_s,ref_e,is_reverse),(node2,node3,...)]
    #      [node1,node2,...],[(node1,node2),...,(),] 三个形式
    aln_graph = {}  # 对应于aln_graph[node_ind] = ((q_s,q_e,ref_s,ref_e,is_reverse),(node2,...))
    for node in cut_alns.keys():
        aln_graph[node] = set()
    all_nodes = []  # 对应于[node1,node2,...]
    node_connects = []  # 对应于[(node1,node2),...,(),]
    ref_end_list = []
    for node in cut_alns.keys():  # enumerate all connections node -> node2
        ref_end_list.append(cut_alns[node][3])
        all_nodes.append(node)
        this_node_connect = []
        for node2 in cut_alns.keys():  # node2 表示所有的next_aln, node 表示current aln
            if node2 != node and node2 > node:
                node_connects.append((node, node2))
                this_node_connect.append(node2)
        aln_graph[node] = [cut_alns[node][:5], this_node_connect]
    # print("aln graph:", aln_graph)
    # print("aln nodes:", all_nodes)
    # print("node connects:", node_connects)

    # 绘图
    if plot_it:
        plot_alns(True, report_dir="/mnt/e/CCSVar2.0/plot_it/result/", aln_graph=aln_graph, current_ind=count)

    # step3: 采用BFS算法寻优，返回最优路径及相应坐标信息，dup_aln,inv_aln
    graph = GraphTraverser()
    graph_dict = graph.gen_graph(all_nodes, node_connects)
    best_paths, inv_alns, dup_alns = graph.bfs_traverse(aln_graph, graph_dict, 0)
    # print("best paths:{0}, inv_alns:{1}, dup_alns:{2}".format(best_paths, inv_alns, dup_alns))

    # step4:对best path,inv aln, dup aln输出分析，处理成candiadate region， 以及tag
    # step 4.1 对于inv，直接tag
    for node in inv_alns:
        # 获取该node（aln）的基本信息
        (q_s, q_e, r_s, r_e, is_reverse) = aln_graph[node][0]
        break_point = r_s
        tag_inv_sig = tag_inv(r_s, r_e, ref_chr, q_name, fasta_open, break_point)
        tag_sigs_all = merge_dicts(tag_sigs_all, tag_inv_sig)

    # step 4.2 对于dup,区分ins、dup， break point 可由best path获得
    # 区分ins、dup：如果aln_ref_end > max_ref_end(除了该aln的所有aln),则为ins
    # 获取所有nodes的ref_end信息：
    max_end_dict = {}
    ref_end_list2 = ref_end_list[:]
    for node in cut_alns.keys():
        cur_end = cut_alns[node][3]
        ref_end_list2.remove(cur_end)
        max_ref_end = max(ref_end_list2)
        # 求得去除该aln之后的最大ref_end值
        max_end_dict[node] = max_ref_end
        ref_end_list2 = ref_end_list[:]

    # 获取所有的nodes的编号
    nodes = list(aln_graph.keys())
    for node in dup_alns:
        if node == nodes[-1]:
            continue
        (q_s, q_e, r_s, r_e, is_reverse) = aln_graph[node][0]
        # 区分ins和dup:如果aln_ref_end > max_ref_end(除了该aln的所有aln),则为ins
        # ins
        if r_e > max_end_dict[node]:
            # 后面进行insertion的tag
            continue
            # tag_ins(q_s, q_e, ref_chr, q_name, prim)
        else:
            # 找到离该dup aln最近的major aln，取得其ref_end作为break_point
            node2 = node
            major_r_e = r_s
            while node2 >= 0:
                node2 -= 1
                if node2 in best_paths:
                    # 获取major aln 的坐标信息
                    major_r_e = aln_graph[node2][0][3]
                    break
            tag_dup_sig = tag_fully_covered(r_s, r_e, q_s, q_e, ref_chr, is_reverse, q_name, prim, major_r_e)
            tag_sigs_all = merge_dicts(tag_sigs_all, tag_dup_sig)

    # step 4.3 解析best path，两个major aln之间两两比较，tag insertion和deletion
    for m in range(len(best_paths) - 1):
        start_node = best_paths[m]
        next_node = best_paths[m + 1]
        # 两两比较aln,处理insertion、deletion
        for j in range(start_node, next_node):
            (cur_q_s, cur_q_e, cur_r_s, cur_r_e, cur_is_rev) = aln_graph[j][0]
            (next_q_s, next_q_e, next_r_s, next_r_e, next_is_rev) = aln_graph[j + 1][0]
            dis_on_read = next_q_s - cur_q_e
            # 在read上的overlap太大直接舍去
            if dis_on_read < -options["max_overlap"]:
                continue
            else:
                # 判断在read上是否存在gap, 存在，则为ins
                if dis_on_read > options["max_gap"]:
                    tag_ins_sig = tag_ins(cur_q_e, next_q_s, ref_chr, q_name, prim)
                    tag_sigs_all = merge_dicts(tag_sigs_all, tag_ins_sig)
                # 判断在ref上是否存在gap，存在，则为del
                if next_r_s > cur_r_e or next_r_e < cur_r_s:
                    tag_del_sig = tag_del(cur_r_s, cur_r_e, next_r_s, next_r_e, ref_chr, fasta_open, q_name)
                    tag_sigs_all = merge_dicts(tag_sigs_all, tag_del_sig)
    return tag_sigs_all
