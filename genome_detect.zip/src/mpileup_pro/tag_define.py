################################
# date: 2021-4-21
# author : zoey
# description : define tag includes ref-homo, ref-hete, read-homo, ref-gap, read-gap
################################

class Tag:
    """
    Deifine tag basic information
    """

    def __init__(self, tag_type, ref_id, pos, read_base, ref_base, read_id, is_covered, tag_from, base_from):
        self.ref_id = ref_id
        self.pos = pos
        self.read_base = read_base
        self.ref_base = ref_base
        self.read_id = read_id
        self.tag_from = tag_from
        self.tag_type = tag_type
        self.is_covered = is_covered
        self.base_from = base_from

    def get_source(self):
        return [self.ref_id, self.pos, self.ref_base, self.read_base, self.read_id,
                self.tag_from, self.tag_type, self.is_covered, self.base_from]

    def to_string(self):
        ref_id, pos, ref_base, read_base, read_id, tag_from, tag_type, is_covered, base_from = self.get_source()
        return "".join("{0} {1} {2} {3} {4} {5} {6} {7} {8}".format
                       (ref_id, pos, ref_base, read_base, read_id, tag_from, tag_type, is_covered, base_from))

    def to_string_cluster(self):
        ref_base, read_base = [self.ref_base, self.read_base]
        return "".join("{0} {1}".format(ref_base, read_base))

    def to_string_for_new_tag(self):
        ref_id, pos, ref_base, read_base, _, _, tag_type, is_covered, base_from = self.get_source()
        return "".join("{0} {1} {2} {3} {4} {5} {6}".format
                       (ref_id, pos, ref_base, read_base, tag_type, is_covered, base_from))


class TagRefHomo(Tag):
    def __init__(self, ref_id, pos, read_base, ref_base, read_id, tag_from):
        self.ref_id = ref_id
        self.pos = pos
        self.ref_base = ref_base
        self.read_base = read_base
        self.read_id = read_id
        self.tag_type = "ref_homo"
        self.is_covered = False
        self.tag_from = tag_from
        self.base_from = ""


class TagRefHete(Tag):
    def __init__(self, ref_id, pos, ref_base, read_base, read_id, tag_from, base_from):
        self.ref_id = ref_id
        self.pos = pos
        self.ref_base = ref_base
        self.read_base = read_base
        self.read_id = read_id
        self.tag_type = "ref_hete"
        self.is_covered = False
        self.tag_from = tag_from
        self.base_from = base_from


class TagfReadHomo(Tag):
    def __init__(self, ref_id, pos, ref_base, read_base, read_id, tag_from):
        self.ref_id = ref_id
        self.pos = pos
        self.ref_base = ref_base
        self.tag_type = "read_homo"
        self.read_base = read_base
        self.read_id = read_id
        self.is_covered = False
        self.tag_from = tag_from
        self.base_from = ""


class TagRefGap(Tag):
    def __init__(self, ref_id, pos, read_base, read_id, tag_from, base_from):
        self.ref_id = ref_id
        self.pos = pos
        self.ref_base = "N"
        self.read_base = read_base
        self.read_id = read_id
        self.tag_type = "ref_gap"
        self.is_covered = False
        self.tag_from = tag_from
        self.base_from = base_from


class TagReadGap(Tag):
    def __init__(self, ref_id, pos, ref_base, read_id, tag_from):
        self.ref_id = ref_id
        self.pos = pos
        self.ref_base = ref_base
        self.read_id = read_id
        self.read_base = "N"
        self.tag_type = "read_gap"
        self.is_covered = False
        self.tag_from = tag_from
        self.base_from = ""


class TagRefGapCovered(TagRefGap):
    def __init__(self, ref_id, pos, read_base, read_id, tag_from, base_from):
        self.ref_id = ref_id
        self.pos = pos
        self.read_base = read_base
        self.read_id = read_id
        self.ref_base = "N"
        self.tag_type = "ref_gap"
        self.is_covered = True
        self.tag_from = tag_from
        self.base_from = base_from


class TagRefHeteCovered(TagRefHete):
    def __init__(self, ref_id, pos, ref_base, read_base, read_id, tag_from, base_from):
        self.ref_id = ref_id
        self.pos = pos
        self.ref_base = ref_base
        self.read_base = read_base
        self.read_id = read_id
        self.tag_type = "ref_hete"
        self.is_covered = True
        self.tag_from = tag_from
        self.base_from = base_from


class NewTag:
    """
    ref_id, pos, ref_base, read_base, tag_type, is_covered, base_from
    """

    def __init__(self, ref_id, pos, ref_base, read_base, tag_type, is_covered, base_from, count):
        self.ref_id = ref_id
        self.pos = pos
        self.read_base = read_base
        self.ref_base = ref_base
        self.tag_type = tag_type
        self.is_covered = is_covered
        self.base_from = base_from
        self.count = count

    def to_string(self):
        return "".join(
            "{0} {1} {2} {3} {4} {5} {6} {7}".format(self.ref_id, self.pos, self.ref_base, self.read_base,
                                                     self.tag_type, self.is_covered, self.base_from, self.count))
