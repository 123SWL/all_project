from tag_define import *
import pysam


def addWord(this_pos_dict, pos, tag_sig):
    """
    add signatures in the same position
    """
    # 存在就在基础上加入列表，不存在就新建个字典key
    this_pos_dict.setdefault(pos, []).append(tag_sig)


def merge_dicts(dict_a, dict_b):
    """
    merge two dicts if they have the same key
    """
    if not bool(dict_a) or not bool(dict_b):
        dict_a.update(dict_b)
        return dict_a
    else:
        result_dict = {}
        for k, v in dict_b.items():
            if k in dict_a:
                result_dict[k] = []
                result_dict[k].extend(dict_a[k])
                result_dict[k].extend(dict_b[k])
                dict_a[k] = result_dict[k]
            else:
                dict_a[k] = v
        return dict_a


def tag_del(cur_r_s, cur_r_e, next_r_s, next_r_e, ref_chr, fasta_open, q_name):
    """
    tag gaps on reference --> deletion
    """
    tag_del_dict = {}
    if next_r_s > cur_r_e:
        del_gap = fasta_open.fetch(ref_chr, cur_r_e, next_r_s)
        for j in range(len(del_gap)):
            # tag_all_sigs.append(
            #     TagReadGap(ref_chr, current_aln["ref_end"] + j + 1, del_gap[j], read_name, "sa"))
            del_pos = cur_r_e + j + 1
            key = del_pos
            value = [TagReadGap(ref_chr, del_pos, del_gap[j], q_name, "sa")]
            addWord(tag_del_dict, key, value)
    else:
        del_gap = fasta_open.fetch(ref_chr, next_r_e, cur_r_s)
        for j in range(len(del_gap)):
            del_pos = next_r_e + j + 1
            key = del_pos
            value = [TagReadGap(ref_chr, del_pos, del_gap[j], q_name, "sa")]
            addWord(tag_del_dict, key, value)
    return tag_del_dict


def tag_ins(cur_q_e, next_q_s, ref_chr, q_name, prim):
    tag_ins_dict = {}
    ins_seq = prim.query_sequence[cur_q_e:next_q_s]
    for j in range(len(ins_seq)):
        ins_pos = cur_q_e + j + 1
        key = ins_pos
        value = [TagRefGap(ref_chr, ins_pos, ins_seq[j], q_name, "sa", "")]
        addWord(tag_ins_dict, key, value)
    return tag_ins_dict


def tag_inv(cur_r_s, cur_r_e, ref_chr, q_name, fasta_open, break_point, is_covered=False):
    """
    tag inversion
    """
    tag_inv_dict = {}
    ref_seq = fasta_open.fetch(ref_chr, cur_r_s, cur_r_e)
    for j in range(len(ref_seq)):
        inv_pos = break_point + j + 1
        read_base = ref_seq[j]
        base_from = cur_r_s + len(ref_seq) - j
        if is_covered:
            value = [TagRefHeteCovered(ref_chr, inv_pos, ref_seq[j], read_base, q_name, "sa", base_from)]
        else:
            value = [TagRefHete(ref_chr, inv_pos, ref_seq[j], read_base, q_name, "sa", base_from)]
        addWord(tag_inv_dict, inv_pos, value)
    return tag_inv_dict


def tag_fully_covered(cur_r_s, cur_r_e, cur_q_s, cur_q_e, ref_chr, is_rev, q_name, prim, break_point_start):
    """
    tag alignments that are fully covered
    is_adjust: adjust the break_point_start
    """
    tag_sigs_dict = {}
    # is_reverse 唯一的区别在于：base from不同
    # 方向与primary相同
    if is_rev:
        ins_seq = prim.query_sequence[cur_q_s:cur_q_e]
        for j in range(len(ins_seq)):
            break_point = break_point_start + j + 1
            read_base = ins_seq[j]
            base_from = cur_r_s + j + 1
            value = [TagRefGapCovered(ref_chr, break_point, read_base, q_name, "sa", base_from)]
            addWord(tag_sigs_dict, break_point, value)
    # aln方向与primary相反
    else:
        inv_ins_seq = prim.query_sequence[cur_q_s:cur_q_e]
        # tag duplication
        for j in range(len(inv_ins_seq)):
            pos = cur_r_s + j + 1
            # break_point = break_point_start - len(inv_ins_seq) + j
            break_point = break_point_start + j + 1  # ?
            read_base = inv_ins_seq[j]
            base_from = cur_r_s + len(inv_ins_seq) - j
            value = [TagRefGapCovered(ref_chr, break_point, read_base, q_name, "sa", base_from)]
            addWord(tag_sigs_dict, break_point, value)
    return tag_sigs_dict
