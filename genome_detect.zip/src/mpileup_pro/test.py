# utf-8
import pysam
from process_sa2 import *
from process_cigar import *
from tag_cluster_2 import *
from multiprocessing import Pool
import random
import time
import sys
#sys.path.append("./coding")
#import coding.code_real_single_4c.parse_cluster_intervals
#from coding.code_real_single_4c import parse_cluster_intervals

from code_real_single_4c import parse_cluster_intervals
#

def process_bam(bam, fasta_open, options, name_list):
    read_count = 0
    tag_all_sigs = {}
    alignments = bam.fetch(reference=options["ref_id"], until_eof=True, start=options["start"], end=options["end"])


    #alignments = bam.fetch(reference=options["ref_id"], until_eof=True, start=None, end=None)
    p = Pool(processes=4)
    while True:
        try:
            curr_alignment = next(alignments)
            if curr_alignment.is_unmapped or curr_alignment.mapping_quality < options["min_quality"]:
                continue
            if curr_alignment.reference_name not in name_list:
                continue
            if curr_alignment.is_supplementary:
                # analyze and tag indel of sa
                tag_sigs = tag_cigar_info(bam, curr_alignment, curr_alignment.query_name, fasta_open)
                tag_all_sigs = merge_dicts(tag_sigs, tag_all_sigs)
            else:
                # analyze primary, and the relationship of supplementary alignments
                read_count += 1
                if read_count % 10 == 0:
                    print("Processed read {0}".format(read_count))

                # acquire supplementary alignments information
                suppl_alignments = get_sa_alignment(bam, curr_alignment, name_list)
                good_suppl_alns = [aln for aln in suppl_alignments if
                                   not aln.is_unmapped and aln.mapping_quality >= options["min_quality"]]

                # analyze and tag indel of primary
                tag_sigs_prim = tag_cigar_info(bam, curr_alignment, curr_alignment.query_name, fasta_open)
                tag_all_sigs = merge_dicts(tag_sigs_prim, tag_all_sigs)

                # analyze relationship of sas
                if len(good_suppl_alns) >= 2:
                    tag_sigs_sa = process_sa2(bam, options, fasta_open, good_suppl_alns, curr_alignment, read_count)
                    tag_all_sigs = merge_dicts(tag_sigs_sa, tag_all_sigs)
        except StopIteration:
            break
        except KeyboardInterrupt:
            print("Execution interrupted by KeyboardInterrupt!")
    print(read_count)
    p.close()
    p.join()
    return tag_all_sigs


def main():
    options = {
        "min_quality": 20,
        "max_overlap": 5,
        "max_gap": 1,
        "max_sv_size": 100000,
        "min_sv_size": 1,
        "ref_id": "chr17",
        "start":83002827,
        "end":83205700
    }

    #bam_file = "/mnt/d/HG002.SequelII.merged_11kb_and_15kb_20kb.pbmm2.GRCh38.phased.bam"
    #bam_file='/mnt/d/HG003.GRCh38.CCS.pbmm2.addrg.deepvariant_phased.bam'
    #bam_file = "/mnt/f/HG002.hifi.pbmm2.sorted.bam"
    bam_file='/mnt/e/data/HG00733.ngmlr.srt.bam'
    bam = pysam.AlignmentFile(bam_file, "rb")

    #fasta_file = "/mnt/f/vcf/hs37d5.fa"
    fasta_file = "/mnt/e/data/GRCh38_chr1-x.fa"
    fasta_open = pysam.FastaFile(fasta_file)

    # ref_name_list = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11",
    #                  "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
    #                  "22", "X"]
    ref_name_list = ["chr1", "chr2", "chr3", "chr4", "chr5", "chr6", "chr7", "chr8", "chr9", "chr10", "chr11",
                                     "chr12", "chr13", "chr14", "chr15", "chr16", "chr17", "chr18", "chr19", "chr20", "chr21",
                                      "chr22", "chrX"]

    # tag
    tag_sigs = process_bam(bam, fasta_open, options, ref_name_list)

    # new tag
    new_tag_dict = preprocess_new_tag(tag_all_sigs_dict=tag_sigs)

    # cluster
    record_intervals = cluster_interval(type_dict_all=new_tag_dict)

    # # encode into 4 channels
    out_path = '/mnt/e/data/output/encode_4c/test/hg003/chr8_cm'
    parse_cluster_intervals(record_intervals, 64, 5, fasta_open, out_path=out_path)


if __name__ == "__main__":
    main()
