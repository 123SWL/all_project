from tag_define import *
from tag_func import addWord


def get_cigar_info(cigartuples):
    """
    Find the position of insertion, deletion and mismatch in the reference.
    """
    ref_pos = 0
    read_pos = 0
    min_length = 2
    sigs = []
    for action, length in cigartuples:
        if action == 0:  # match
            ref_pos += length
            read_pos += length
        elif action == 1:  # insertion
            if length >= min_length:
                sigs.append((ref_pos, read_pos, length, "INS"))
            read_pos += length
        elif action == 2:  # deletion
            if length >= min_length:
                sigs.append((ref_pos, read_pos, length, "DEL"))
            ref_pos += length
        elif action == 4:  # soft clip or ref skip
            read_pos += length
        elif action == 7:  # =, match
            sigs.append((ref_pos, read_pos, length, "Match"))
            ref_pos += length
            read_pos += length
        elif action == 8:  # mismatch(X)
            sigs.append((ref_pos, read_pos, length, "Mismatch"))  # mismatch
            ref_pos += length
            read_pos += length
        elif action == 3:  # ref skip
            read_pos += length
        else:
            pass
    return sigs


def tag_cigar_info(bam, alignment, query_name, fasta_open):
    """
    tag each indel from cigar
    """
    ref_chr = bam.getrname(alignment.reference_id)
    ref_start = alignment.reference_start
    cigar_tuple = alignment.cigartuples
    sigs = get_cigar_info(cigar_tuple)
    # tag_sigs = []
    tag_sigs_2 = {}
    for ref_pos, read_pos, length, type in sigs:
        # type -- "INS, DEL, Match, Mismatch
        if type == "INS":  # gap -> A, ref-gap
            ins_seq = alignment.query_sequence[read_pos:read_pos + length]
            for i in range(len(ins_seq)):
                ins_alt = ins_seq[i]
                ins_pos = ref_start + ref_pos + i + 1
                # tag_sigs.append(TagRefGap(ref_chr, ins_pos, ins_alt, query_name, "cigar"))
                key = ins_pos
                value = [TagRefGap(ref_chr, ins_pos, ins_alt, query_name, "cigar", "")]
                addWord(tag_sigs_2, key, value)
        elif type == "DEL":  # A -> gap, read-gap
            ref_seq = fasta_open.fetch(ref_chr, ref_start + ref_pos, ref_start + ref_pos + length)
            for i in range(length):
                ref_base = ref_seq[i]
                del_pos = ref_start + ref_pos + i + 1
                # tag_sigs.append(TagReadGap(ref_chr, del_pos, ref_base, query_name, "cigar"))
                key = del_pos
                value = [TagReadGap(ref_chr, del_pos, ref_base, query_name, "cigar")]
                addWord(tag_sigs_2, key, value)
        elif type == "Match":  # A -> A, ref-homo
            match_seq = alignment.query_sequence[read_pos: read_pos + length]  # ? match-seq 的长度和length不同 ?
            ref_seq = fasta_open.fetch(ref_chr, ref_start + ref_pos,
                                       ref_start + ref_pos + length)  # fetch 需要 减1， 记录按照igv的坐标记
            for i in range(len(match_seq)):
                read_base = match_seq[i]
                match_pos = ref_start + ref_pos + i + 1
                # tag_sigs.append(TagRefHomo(ref_chr, match_pos, read_base, ref_seq[i], query_name, "cigar"))
                key = match_pos
                value = [TagRefHomo(ref_chr, match_pos, read_base, ref_seq[i], query_name, "cigar")]
                addWord(tag_sigs_2, key, value)
        elif type == "Mismatch":
            mismat_seq = alignment.query_sequence[read_pos:read_pos + length]
            ref_seq = fasta_open.fetch(ref_chr, ref_start + ref_pos, ref_start + ref_pos + length)
            for i in range(len(mismat_seq)):
                mismat_alt = mismat_seq[i]
                ref_base = ref_seq[i]
                mismat_pos = ref_start + ref_pos + i + 1
                # tag_sigs.append(TagRefHete(ref_chr, mismat_pos, ref_base, mismat_alt, query_name, "cigar"))
                key = mismat_pos
                value = [TagRefHete(ref_chr, mismat_pos, ref_base, mismat_alt, query_name, "cigar", " ")]
                addWord(tag_sigs_2, key, value)
        else:
            pass
    return tag_sigs_2
