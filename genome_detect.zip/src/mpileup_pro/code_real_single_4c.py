#####################################################################
# encoding:utf-8
# author: zoey
# version: 1
# date: 2021-6-25
# description:
#             1- judge inv/invdup, dup/invdup
#             2- encode into 4 channels
######################################################################
import os
import numpy as np
import cv2
import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt


def encode_candidate(interval_dis, interval_start, img_start, this_interval, img, tag_type, support_num):
    A = 0
    C = 1
    G = 2
    T = 3
    N = 4
    for i in range(interval_dis):
        this_pos = interval_start + i
        dup_inv_flag = False
        # 遍历某个pos下的所有tag信息，进行encode
        for j in range(len(this_interval) - 1):
            if int(this_interval[j].pos) == this_pos:
                pos_img = img_start + i
                ref_base = this_interval[j].ref_base
                read_base = this_interval[j].read_base
                is_covered = this_interval[j].is_covered
                base_from = this_interval[j].base_from
                # support_num = this_interval[j].count

                # first channel: ref
                if ref_base == 'A':
                    img[A][pos_img][0] = support_num
                elif ref_base == 'C':
                    img[C][pos_img][0] = support_num
                elif ref_base == 'G':
                    img[G][pos_img][0] = support_num
                elif ref_base == 'T':
                    img[T][pos_img][0] = support_num
                # elif ref_base == 'N':
                #     img[N][pos_img][0] = support_num
                # else:
                #     pass

                # second channel: read
                if read_base == 'A':
                    img[A][pos_img][1] = support_num
                elif read_base == 'C':
                    img[C][pos_img][1] = support_num
                elif read_base == 'G':
                    img[G][pos_img][1] = support_num
                elif read_base == 'T':
                    img[T][pos_img][1] = support_num
                # elif ref_base == 'N':
                #     img[N][pos_img][1] = support_num
                # else:
                #     pass

                # third & forth channel
                base_from_cur = this_interval[j].base_from
                base_from_next = this_interval[j + 1].base_from
                # 当base_from不为空时，一定发生dup（4#） or inv（3#）
                if base_from != "":
                    # 为单纯的dup: ref_gap, base_from递增 （encode 4#）
                    # 为 dup + inv: ref_gap, base_from 递减（此时需要encode 4#，将 4# 的图像copy 到 3#）
                    # 为单纯的inv：ref_hete, base_from递减
                    if tag_type == "ref_gap":
                        if base_from_next != "" and int(base_from_next) < int(base_from_cur):
                            dup_inv_flag = True  # 表示invdup

                        if read_base == 'A':
                            img[A][pos_img][3] = support_num
                        elif read_base == 'C':
                            img[C][pos_img][3] = support_num
                        elif read_base == 'G':
                            img[G][pos_img][3] = support_num
                        elif read_base == 'T':
                            img[T][pos_img][3] = support_num
                        else:
                            pass

                    # third channel: inv/invdup
                    # 单纯inv
                    if tag_type == "ref_hete":
                        if read_base == 'A':
                            img[A][pos_img][2] = support_num
                        elif read_base == 'C':
                            img[C][pos_img][2] = support_num
                        elif read_base == 'G':
                            img[G][pos_img][2] = support_num
                        elif read_base == 'T':
                            img[T][pos_img][2] = support_num
                        elif ref_base == 'N':
                            img[N][pos_img][2] = support_num
                        else:
                            pass
                    # inv_dup, 将4# 的图像拷贝到 3#
                    if dup_inv_flag:
                        if read_base == 'A':
                            img[A][pos_img][2] = support_num
                        elif read_base == 'C':
                            img[C][pos_img][2] = support_num
                        elif read_base == 'G':
                            img[G][pos_img][2] = support_num
                        elif read_base == 'T':
                            img[T][pos_img][2] = support_num
                        elif ref_base == 'N':
                            img[N][pos_img][2] = support_num
                        else:
                            pass
                    else:
                        pass
                else:
                    pass

                # third channel: inv/invdup channel
                # if tag_type == "ref_hete" and base_from != "":
                #     if read_base == 'A':
                #         img[A][pos_img][2] = support_num
                #     elif read_base == 'C':
                #         img[C][pos_img][2] = support_num
                #     elif read_base == 'G':
                #         img[G][pos_img][2] = support_num
                #     elif read_base == 'T':
                #         img[T][pos_img][2] = support_num
                #     # elif ref_base == 'N':
                #     #     img[N][pos_img][2] = support_num
                #     else:
                #         pass
                #
                # # forth channel: dup/invdup channel
                # if tag_type == "ref_gap" and base_from != "":
                #     if read_base == 'A':
                #         img[A][pos_img][3] = support_num
                #     elif read_base == 'C':
                #         img[C][pos_img][3] = support_num
                #     elif read_base == 'G':
                #         img[G][pos_img][3] = support_num
                #     elif read_base == 'T':
                #         img[T][pos_img][3] = support_num
                #     # elif ref_base == 'N':
                #     #     img[N][pos_img][3] = support_num
                #     else:
                #         pass
            else:
                continue
    return img


def encode_ref_homo(img, start, end, img_start, fasta_open, ref_chr, coverage):
    A = 0
    C = 1
    G = 2
    T = 3
    N = 4
    ref_seq = fasta_open.fetch(ref_chr, start, end + 1)
    # print(len(ref_seq))
    for i in range(len(ref_seq)):
        ref_base = ref_seq[i]
        read_base = ref_seq[i]
        pos_img = img_start + i
        # print(pos_img, ref_base, read_base)
        # 开始 encode
        # first channel: ref
        if ref_base == 'A':
            img[A][pos_img][0] = coverage
        elif ref_base == 'C':
            img[C][pos_img][0] = coverage
        elif ref_base == 'G':
            img[G][pos_img][0] = coverage
        elif ref_base == 'T':
            img[T][pos_img][0] = coverage
        # elif ref_base == 'N':
        #     img[N][pos_img][0] = coverage
        else:
            pass

        # second channel: read
        if read_base == 'A':
            img[A][pos_img][1] = coverage
        elif read_base == 'C':
            img[C][pos_img][1] = coverage
        elif read_base == 'G':
            img[G][pos_img][1] = coverage
        elif read_base == 'T':
            img[T][pos_img][1] = coverage
        # elif ref_base == 'N':
        #     img[N][pos_img][1] = coverage
        else:
            pass
    return img


def encode_sampling(image, image_length):
    """
    对于大于64 bp， 图片层面进行采样
    """
    ratio = image.shape[1] / image_length  # 此处可以改变图像的分辨率
    image1 = np.zeros((int(image.shape[0]),
                       int(image.shape[1] / ratio),
                       image.shape[2]), dtype='float32')

    for i in range(image1.shape[0]):
        for j in range(image1.shape[1]):
            for k in range(image1.shape[2]):
                delta = image[i, int(j * ratio), k]
                image1[i, j, k] = delta
    return image1


def encode_4c(this_interval, image_length, image_height, img, tag_type, fasta_open):
    interval_start = int(this_interval[0].pos)
    interval_end = int(this_interval[-1].pos)
    interval_dis = interval_end - interval_start + 1
    interval_len = len(this_interval)

    # 获取ref chr
    ref_chr = this_interval[0].ref_id
    # 获取coverage的分布情况
    coverage_list = []
    for index in range(interval_len):
        coverage_list.append(int(this_interval[index].count))

    max_coverage = max(coverage_list)
    support_num = int(sum(coverage_list) / len(coverage_list))

    # 问题区间小于指定图片的宽度
    if interval_dis <= image_length:
        # print("< 64:", interval_dis)
        # 计算距离
        distance = image_length - interval_dis
        # 记录ref上的位置
        seq_a_start = interval_start - (distance // 2)
        seq_a_end = interval_start - 1
        seq_b_start = interval_end + 1
        seq_b_end = interval_end + distance - distance // 2
        # 记录img的位置
        img_a_start = 0
        img_b_start = distance // 2 + interval_dis
        img_start = distance // 2  # 有问题区间的开始坐标

        # print("distance：", distance)
        # print("interval start:", interval_start, "interval end:", interval_end)
        # print("seq_a_start:", seq_a_start, " seq_a_end:", seq_a_end)
        # print("seq_b_start:", seq_b_start, " seq_b_end:", seq_b_end)
        # print("img_a_start:", img_a_start)
        # print("img_b_start:", img_b_start)

        # encode ref homo: 获取问题区间两边的序列 以及 coverage 等信息, 并进行encode
        img = encode_ref_homo(img, seq_a_start, seq_a_end, img_a_start, fasta_open, ref_chr, support_num)
        img = encode_ref_homo(img, seq_b_start, seq_b_end, img_b_start, fasta_open, ref_chr, support_num)

        # encode 问题区间
        img = encode_candidate(interval_dis, interval_start, img_start, this_interval, img, tag_type, support_num)

        # normalise img
        normalised_img = (img - np.min(img)) / (np.max(img) - np.min(img)) * 255
    # > image_length (64):序列压缩，先encode为真实大小，再从图片角度进行压缩
    else:
        # print("> 64:", interval_dis)
        seq_a_start = interval_start - int(0.1 * interval_dis)
        seq_a_end = interval_start - 1
        seq_b_start = interval_end + 1
        seq_b_end = seq_b_start + int(0.1 * interval_dis) - 1
        img_a_start = 0
        img_b_start = int(0.1 * interval_dis) + interval_dis
        img_start = int(0.1 * interval_dis)  # 有问题区间的开始坐标

        # print("interval start:", interval_start, "interval end:", interval_end)
        # print("seq_a_start:", seq_a_start, " seq_a_end:", seq_a_end)
        # print("seq_b_start:", seq_b_start, " seq_b_end:", seq_b_end)
        # print("img_a_start:", img_a_start)
        # print("img_b_start:", img_b_start)

        # encode ref homo：问题区间两边取10%的序列, 初始化图片长度为max_len
        max_len = int(interval_dis + 0.2 * interval_dis)
        img_large = np.zeros((image_height, max_len, 4))

        img_large = encode_ref_homo(img_large, seq_a_start, seq_a_end, img_a_start, fasta_open, ref_chr, support_num)
        img_large = encode_ref_homo(img_large, seq_b_start, seq_b_end, img_b_start, fasta_open, ref_chr, support_num)

        # encode 问题区间
        img = encode_candidate(interval_dis, interval_start, img_start, this_interval, img_large, tag_type, support_num)

        # normalise img
        normalised_img = (img - np.min(img)) / (np.max(img) - np.min(img)) * 255

        # sampling 压缩图片
        normalised_img = encode_sampling(normalised_img, image_length)

        # resize 压缩图片
        # size = (image_length, image_height)
        # img = cv2.resize(img_large, size, interpolation=cv2.INTER_AREA)

    return normalised_img


def parse_cluster_intervals(interval_dict, image_length, image_height, fasta_open, out_path):
    """
    input: {tag_type1: [[tag1, tag2, ...], [tag1, tag2, tag3...], ...], tag_type2: ...}
    """
    count = 0
    out_path2 = '/mnt/e/CCSVar2.0/vcf/'
    output_re = open(os.path.join(out_path2, 'result_record_hg00733_chr17_1.vcf'), 'w')
    print('id', file=output_re)
    # interval list 包括[有base from， 没有base from]
    for tag_type, intervals_list in interval_dict.items():
        # 遍历每一个interval
        for intervals in intervals_list:
            for i in range(len(intervals)):
                count += 1
                if count % 10 == 0:
                    print("Processed intervals {0}".format(count))
                img = np.zeros((image_height, image_length, 4))
                normalised_img = encode_4c(intervals[i], image_length, image_height, img, tag_type, fasta_open)
                cv2.imwrite(os.path.join(out_path, 'chr17_1_{0}.png'.format(count)), normalised_img)



                ############  用于生成vcf所需要的东西
                read = ''
                reference = ''
                interval_start = int(intervals[i][0].pos)
                interval_end = int(intervals[i][-1].pos)
                interval_len = len(intervals[i])
                for k in range(interval_len):
                    read += intervals[i][k].read_base
                    reference += intervals[i][k].ref_base
                # 获取ref chr
                ref_chr = intervals[i][0].ref_id
                # 获取coverage的分布情况
                coverage_list = []
                for index in range(interval_len):
                    coverage_list.append(int(intervals[i][index].count))

                max_coverage = max(coverage_list)
                support_num = int(sum(coverage_list) / len(coverage_list))
                VAF = support_num / max_coverage

                print(str(ref_chr) + ' ' + str(interval_start) + ' ' + str(count) + ' ' + str(reference) + ' ' + str(
                    read) + ' ' + '.' + ' ' + '.' + ' '
                      + str(interval_len) + ' ' + str(interval_end) + ' ' + str(VAF) + ' ' + str(support_num),
                      file=output_re)
                ###########  此处结束



                # 显示 interval 信息
                # for j in range(len(intervals[i])):
                #     print(intervals[i][j].to_string())

                #plot for show
                plt.subplot(411)
                plt.imshow(normalised_img[:, :, 0])
                plt.yticks([])

                plt.subplot(412)
                plt.imshow(normalised_img[:, :, 1])
                plt.yticks([])

                plt.subplot(413)
                plt.imshow(normalised_img[:, :, 2])
                plt.yticks([])

                plt.subplot(414)
                plt.imshow(normalised_img[:, :, 3])
                plt.yticks([])
                plt.savefig(os.path.join(out_path, 'chr17_1_show_{0}.png'.format(count)))
