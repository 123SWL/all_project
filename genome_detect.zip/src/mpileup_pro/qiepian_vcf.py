def cut_vcf(chr,position_start,position_end,file,outpath):
    f = open(file, 'r')

    for line in f.readlines():
        if '#' in line:
            #print(line,file=outpath,end='')
            continue
        else:
            # print(line)
            curline = line.split("\t")
            # print(curline)
            if curline[0]==chr and position_start<=int(curline[1])<=position_end:
                print(line,file=outpath,end='')

#file='/mnt/f/HG002.GRCh38.CCS.pbmm2.deepvariant.phased.vcf'
#file='/mnt/f/vcf/hg007/HG002_NA24385_son_all.varscan.s2.vcf'
#file='/mnt/f/HG002_NA24385_son.varscan.s2.vcf'
file='/mnt/f/vcf/hg007/CCSD/HG007-dipcall-hg38_1.vcf'
#file='/mnt/f/vcf/hg007/HG002_indel.s2.vcf'
#outpath=open('/mnt/f/vcf/h38/final/dv_hg002_all.vcf', 'a+')
outpath=open('/mnt/f/vcf/hg007/CCSD/HG007_real.vcf', 'a+')
# cut_vcf('chr4',1056649,1069399,file,outpath)
# cut_vcf('chr5',140859344,140959956,file,outpath)
# cut_vcf('chr6',168624886,168654432,file,outpath)
# cut_vcf('chr7',5275101,5306565,file,outpath)
# cut_vcf('chr8',1897496,1949809,file,outpath)
# cut_vcf('chr9',69039128,69088028,file,outpath)
# cut_vcf('chr10',101415546,101499739,file,outpath)
# cut_vcf('chr11',665182,699852,file,outpath)
# cut_vcf('chr12',63600500,63668907,file,outpath)
# cut_vcf('chr13',113164394,113171786,file,outpath)
# cut_vcf('chr14',92116128,92121875,file,outpath)
# cut_vcf('chr15',41393121,43586949,file,outpath)
# cut_vcf('chr16',164953,317174,file,outpath)
cut_vcf('chr22',16004065,16546076,file,outpath)

#cut_vcf('chr3',333133,399619,file,outpath)
import os


# def cut_vcf(file1,outpath):
#     dict1={}
#     #count,i=10,0
#     with open(file1, 'r') as f:
#         lines = f.readlines()
#         for line in lines:
#             if line!='/n':
#                 key=int(line.split('\t')[1])
#                 value=line
#                 dict1[key]=value
#                 print(dict1)
#     a=sorted(dict1)
#     for i in a:
#         print(dict1[i],file=outpath,end='')
#     # # # 文本排序并保存
#     # output_file = './search.txt'
#     # output_file_sort = './search_sort.txt'
#     # with open(outpath, 'a+') as writersort:
#     #     print(''.join(sorted(open(file1), key=lambda s: s.split('\t')[1])))
#         #writersort.write(''.join(sorted(open(file), key=lambda s: s.split('\t')[1], reverse=False)))
# def head_vcf(file1,outpath):
#     with open(file1, 'r') as r:
#         lines = r.readlines()
#     with open(file1, 'w') as w:
#         for l in lines:
#             if '#' not in l:
#                 w.write(l)
#             else:
#                 print(l,file=outpath,end='')
# def zhuanyichr(file1,outpath,outpath1,outpath2,outpath3,outpath4,outpath5):
#     with open(file1, 'r') as f:
#         lines = f.readlines()
#         for line in lines:
#             if 'chr1' in line:
#                 print(line, file=outpath, end='')
#             elif 'chr2' in line:
#                 print(line,file=outpath1, end='')
#             elif 'chr3' in line:
#                 print(line, file=outpath2, end='')
#             elif 'chr4' in line:
#                 print(line, file=outpath3, end='')
#             elif 'chr5' in line:
#                 print(line, file=outpath4, end='')
#             elif 'chr6' in line:
#                 print(line, file=outpath5, end='')
#
#
# file1='/mnt/f/vcf/hg00733/varsc_hg002_chr1.vcf'
# #outpath='/mnt/f/vcf/hg007/varsc_hg002_chr1.vcf'
# outpath = open('/mnt/f/vcf/hg00733/hg002_chr1.vcf', 'a+')
# outpath1 = open('/mnt/f/vcf/hg00733/hg002_chr2.vcf', 'a+')
# outpath2 = open('/mnt/f/vcf/hg00733/hg002_chr3.vcf', 'a+')
# outpath3 = open('/mnt/f/vcf/hg00733/hg002_chr4.vcf', 'a+')
# outpath4 = open('/mnt/f/vcf/hg00733/hg002_chr5.vcf', 'a+')
# outpath5 = open('/mnt/f/vcf/hg00733/hg002_chr6.vcf', 'a+')
# #先保存#，后删除#排序输出
# #head_vcf(file1,outpath)
# #cut_vcf(file1,outpath)
# zhuanyichr(file1,outpath,outpath1,outpath2,outpath3,outpath4,outpath5)
