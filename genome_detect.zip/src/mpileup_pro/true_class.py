import os
import re
class_list=[]
with open(os.path.join('/mnt/e/data/visor_data/input/HACk.valid2.bed'), 'r') as bed_file:
    for line in bed_file.readlines():
        curline=line.split('\t')
        if curline[3]=='inversion':
            class_list.append(3)
        elif curline[3]=='inverted tandem duplication':
            class_list.append(5)
        elif curline[3]=='tandem duplication':
            class_list.append(4)
        elif curline[3]=='deletion':
            class_list.append(2)
        elif curline[3]=='insertion':
            class_list.append(1)
        else:
            class_list.append(0)
