import os

import matplotlib.pyplot as plt
import numpy as np

# #求前几位相同，取到倒数第一位，
# file1='/mnt/e/CCSVar2.0/sim/sim_clone0.benchmark.vcf'
# file2='/mnt/e/CCSVar2.0/sim/result_record_invdup_10.txt'
# list1=[]
# list2=[]
# count,num=0,0
# with open(file1, "r") as f1:
#     files = f1.readlines()
#     for file in files:
#         if '#' in file:
#             continue
#         # print(file.split(' '))
#         pos= file.split('\t')[1]
#         list1.append(int(pos[:-2]))
# with open(file2, "r") as f2:
#     files1 = f2.readlines()
#     for file1 in files1:
#         if 'id' in file1:
#             continue
#         # print(file.split(' '))
#         pos= file1.split(' ')[1]
#         #print(pos)
#         lenn=file1.split(' ')[3]
#         #print(len(lenn))
#         if len(lenn)>=45:
#             list2.append(int(pos[:-2]))
#             num+=1
#             print(num)
# # with open(file2, "r") as f2:
# #     files1 = f2.readlines()
# #     for file1 in files1:
# #         if '#' in file1:
# #             continue
# #         # print(file.split(' '))
# #         pos= file1.split('\t')[1]
# #         list2.append(int(pos[:-2]))
# #         num+=1
#
# for i in list2:
#     if i in list1:
#         print('f',i)
#         count+=1
# p=count/num
# print(len(list1))
# print(count)
# print(num)
# r=count/500
# f1=2*p*r/(r+p)
p=0.6702
r=0.6794
f1=2*p*r/(r+p)
print(p)
print(r)
print(f1)
# img='/mnt/e/CCSVar2.0/sim/chrX/inv_28_630.png'
# out_file='/mnt/e/CCSVar2.0/sim/test/'
#
# def write_pic(img, maxx, prob, count, out_file):
#     # plot for show
#     plt.subplot(411)
#     plt.imshow(img[:, :, 0])
#     plt.yticks([])
#
#     plt.subplot(412)
#     plt.imshow(img[:, :, 1])
#     plt.yticks([])
#
#     plt.subplot(413)
#     plt.imshow(img[:, :, 2])
#     plt.yticks([])
#
#     plt.subplot(414)
#     plt.imshow(img[:, :, 3])
#     plt.yticks([])
#     plt.savefig(os.path.join(out_file, '{0}_{1:.4f}_{2}_show.png'.format(maxx, prob, count)))
# write_pic(img,6,0.68,1,out_file)