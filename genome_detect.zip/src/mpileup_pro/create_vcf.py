import time
import os
from itertools import zip_longest

import pysam
import sys
import csv

def output_vcf_header_final(ref_path, output_vcf):
    """
    generate vcf header
    """
    version = '1.0'
    #target_name = target_path.split("/")[-1]

    # base_names = []
    # for base_name in base_path:
    #     base_names.append(base_name.split("/")[-1])
    # base_names = "\t".join(base_names)

    print("##fileformat=VCFv4.3", file=output_vcf)
    print("##source=SVDET v{0}".format(version), file=output_vcf)

    # # STEP: add chromosome info
    ref_file = pysam.FastaFile(ref_path)
    chroms = ref_file.references
    for chr in chroms:
        chr_length = ref_file.get_reference_length(chr)
        print('##contig=<ID={0},length={1}>'.format(chr, chr_length), file=output_vcf)

    # # STEP: add info field
    print("##CHROM=<CHROM=XXX,Description=\"Chromosome ID\">", file=output_vcf)
    print("##POS=<POS=XXX,Description=\"Start position of the variant described in this region\">", file=output_vcf)
    #print("##ID=<ID=XXX,Description=\"ID of the variant described in this region\">", file=output_vcf)
    print("##REF=<REF=N,Description=\"Ref's sequence in that region, default=N\">", file=output_vcf)
    print("##QUAL=<QUAL=20,Description=\"The variant quality of the variant described in this region\">", file=output_vcf)

    print("##ALT=<ID=SV,Description=\"Simple SVs\">", file=output_vcf)
    print("##ALT=<ID=X,Description=\"SNP\">", file=output_vcf)

    print("##FILTER=<ID=PASS,Description=\"Passed\">", file=output_vcf)
    print("##FILTER=<ID=POLY,Description=\"Polymorphic\">", file=output_vcf)

    print("##INFO=<ID=END,Number=1,Type=Integer,Description=\"End position of the variant described in this region\">", file=output_vcf)
    print("##INFO=<ID=SUPPORT,Number=1,Type=Integer,Description=\"variant support number in this region\">", file=output_vcf)
    print("##INFO=<ID=SVTYPE,Number=1,Type=String,Description=\"Type of structural variant\">", file=output_vcf)
    print("##INFO=<ID=SVLEN,Number=1,Type=Integer,Description=\"Difference in length between REF and ALT alleles\">", file=output_vcf)
    print("##INFO=<ID=VAF,Number=1,Type=Float,Description=\"varaint alleles freguency in this region\">",file=output_vcf)
    print("##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">",file=output_vcf)
    print("##FORMAT=<ID=DP,Number=1,Type=Integer,Description=\"Read depth\">",file=output_vcf)
    print("##FORMAT=<ID=AD,Number=R,Type=Integer,Description=\"Read depth for each allele\">",file=output_vcf)
    ##FORMAT=<ID=DP,Number=1,Type=Integer,Description="Read depth">
    ##FORMAT=<ID=AD,Number=R,Type=Integer,Description="Read depth for each allele">
    print("#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tNULL", file=output_vcf)


def write_vdf_inside(output_vcf,class_file,interval_file):

#class_file and interval_file combine
    with open(interval_file) as f:
        txt1 = [r.rstrip("\n") for r in f.readlines()]
    with open(class_file) as f:
        txt2 = [r.rstrip("\n") for r in f.readlines()]
    result =zip_longest(txt1, txt2, fillvalue=' ')
    with open("/mnt/f/vcf/h38/final/final_chr2.txt", "w+") as f:
        [f.write(' '.join(r) + "\n")for r in result]
    with open("/mnt/f/vcf/h38/final/final_chr2.txt", "r") as f1:
        files = f1.readlines()
        for file in files:
            if 'id' in file:
                continue
            #print(file.split(' '))
            chr_1,pos,id_1,ref,alt,qual,filter_1,sv_len,end,vaf,support,_,svtype,_=file.split(' ')
            #chr_1=chr_1[3:]#GRCh37
            if int(sv_len)>1:
                pos=int(pos)-1
            if svtype=='1':#insertion
                print('{0}\t{1}\t.\t{6}\t{7}\t20\tPASS\tSVTYPE=INS;SVLEN={2};END={3};VAF={4};SUPPORT={5}\tGT:DP:AD\t./.:.:.'.format(chr_1,int(pos),int(sv_len),int(pos),float(vaf),int(support),ref,alt),file=output_vcf)
            elif svtype=='2':
                print('{0}\t{1}\t.\t{6}\t{7}\t20\tPASS\tSVTYPE=DEL;SVLEN={2};END={3};VAF={4};SUPPORT={5}\tGT:DP:AD\t./.:.:.'.format(chr_1, int(pos),-int(sv_len), int(end),float(vaf),int(support),ref,alt),file=output_vcf)
            elif svtype=='3':
                print('{0}\t{1}\t.\t{6}\t{7}\t20\tPASS\tSVTYPE=INV;SVLEN={2};END={3};VAF={4};SUPPORT={5}\tGT:DP:AD\t./.:.:.'.format(chr_1, int(pos), int(sv_len), int(end),float(vaf),int(support),ref,alt),file=output_vcf)
            elif svtype=='4'and int(sv_len)>1:
                print('{0}\t{1}\t.\t{6}\t{7}\t20\tPASS\tSVTYPE=DUP;SVLEN={2};END={3};VAF={4};SUPPORT={5}\tGT:DP:AD\t./.:.:.'.format(chr_1, int(pos),int(sv_len), int(end),float(vaf),int(support),ref,alt),file=output_vcf)
            elif svtype=='5' and int(sv_len)>1:
                print('{0}\t{1}\t.\t{6}\t{7}\t20\tPASS\tSVTYPE=INVDUP;SVLEN={2};END={3};VAF={4};SUPPORT={5}\tGT:DP:AD\t./.:.:.'.format(chr_1, int(pos),int(sv_len), int(end),float(vaf),int(support),ref,alt),file=output_vcf)
            elif svtype=='0' and sv_len=='1':
                print('{0}\t{1}\t.\t{2}\t{3}\t20\tPASS\tSVTYPE=SNP;SVLEN=1;END={1};VAF={4};SUPPORT={5}\tGT:DP:AD\t./.:.:.'.format(chr_1, int(pos), ref[0],alt[0],float(vaf),int(support)),file=output_vcf)
            elif sv_len=='1':
                print('{0}\t{1}\t.\t{2}\t{3}\t20\tPASS\tSVTYPE=SNP;SVLEN=1;END={1};VAF={4};SUPPORT={5}\tGT:DP:AD\t./.:.:.'.format(chr_1, int(pos), ref[0],alt[0],float(vaf),int(support)),file=output_vcf)

#vcf of hg002
class_file='/mnt/f/vcf/hg00733/pr/result_hg00733_35.txt'
interval_file='/mnt/f/vcf/hg00733/image/vcf/result_record_hg00733_chr17_35.vcf'

out_path = '/mnt/f/vcf/hg00733/final/'
output_vcf = open(os.path.join(out_path, 'hg00733_1.vcf'), 'a+')
ref_path = '/mnt/f/GRCh38.d1.vd1.fa'
#output_vcf_header_final(ref_path,output_vcf)
write_vdf_inside(output_vcf,class_file,interval_file)
#
