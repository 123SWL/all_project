from pysam import VariantFile
def removeInfo(vcf_path , info_name ,out_path):
    vcf = VariantFile(vcf_path)
    out = open(out_path, "w")
    print(vcf.header , end='',file=out)
    for sv in vcf.fetch() :
      if info_name in sv.info:
          del sv.info[info_name]
          print(sv, end='',file=out)
      else:
          print(sv, end='',file=out)
    out.close()


vcf='/mnt/f/HG007-dipcall-hg38.vcf'
info='MatchId'
put='/mnt/f/HG007-dipcall-hg38_1.vcf'
removeInfo(vcf,info,put)