import networkx as nx
import matplotlib.pyplot as plt


class GraphTraverser(object):
    """图遍历器，基于networks展示图
    """

    def __init__(self):
        return

    def gen_graph(self, node_list=None, edge_list=None):
        """生成图, 返回一个图词典，用来存储图
        :param node_list:
        :param edge_list:
        :return:
        """
        graph = nx.MultiDiGraph()
        graph.add_nodes_from(node_list)
        graph.add_edges_from(edge_list)
        # nx.draw(graph, with_labels=True)
        # plt.show()
        graph_dict = {}
        for node in node_list:
            graph_dict[node] = [next_node[1] for next_node in edge_list if next_node[0] == node]
        return graph_dict

    def dfs_traverse(self, graph, start_node):
        """深度优先访问 栈实现 filo, 回溯
        :param graph:
        :param start_node:
        :return:
        """
        stack = [start_node]
        visited = set()  # 看是否访问过
        visited.add(start_node)
        while len(stack) > 0:
            # 拿出邻接点
            vertex = stack.pop()  # 这里pop参数没有0了，最后一个元素
            nodes = graph[vertex]
            for next_node in nodes:
                if next_node not in visited:  # 如何判断是否访问过，使用一个数组
                    stack.append(next_node)
                    visited.add(next_node)
            print(vertex)

    def bfs_traverse(self, aln_graph, graph, start_node):
        """广度优先遍历, 队列实现 fifo
        :param graph:
        :param start_node:
        :return:
        """
        queue = [start_node]
        visited = set()  # 看是否访问过该结点
        visited.add(start_node)
        dup_alns = []
        inv_alns = []
        paths = []
        while len(queue) > 0:
            vertex = queue.pop(0)  # 保存第一结点，并弹出，方便把他下面的子节点接入
            nodes = graph[vertex]  # 子节点的数组
            # print("nodes:", nodes)
            for next_node in nodes:
                (cur_q_s, cur_q_e, cur_ref_s, cur_ref_e, cur_is_rev), _ = aln_graph[vertex]
                (next_q_s, next_q_e, next_ref_s, next_ref_e, next_is_rev), _ = aln_graph[next_node]
                # 判断是否存在dup(走回头路): next_ref_start < cur_ref_end
                # 判断是否存在inv：is_reverse = False
                if next_ref_s < cur_ref_e or not next_is_rev:
                    cur_len = cur_ref_e - cur_ref_s
                    next_len = next_ref_e - next_ref_s
                    if cur_len < next_len:
                        dup_alns.append(vertex)
                    else:
                        dup_alns.append(next_node)
                    inv_alns.append(next_node)
                    continue
                if next_node not in visited:  # 判断是否访问过
                    queue.append(next_node)
                    visited.add(next_node)
            paths.append(vertex)
            # print("vertex:", vertex)
        return paths, inv_alns, dup_alns
