#####################################################################
# encoding:utf-8
# author: zoey
# version: 3
# date: 2021-6-21
# description:
#             1- generate new tag: [old_tag, support_num]
#             2- correct some ref_hete into read_homo
#             3- find candidate sv region according to clustering
######################################################################
from tag_define import NewTag
import time
from collections import Counter


def generate_new_tag(tag_all_sigs_dict):
    """
    generate new tag: [old_tag, support_num]
    """
    # tag_sorted_dict --> {pos1:[[tag1], [tag2], ...], pos2: [[tag1], [tag2], ...]}
    tag_sorted_dict = sorted(tag_all_sigs_dict.items(), key=lambda x: x[0], reverse=False)
    new_tag_dict = {}
    for pos, values in tag_sorted_dict:  # values = [tag1, tag2, ...]
        new_tag_strs = []
        for i in range(len(values)):  # 遍历每一个tag
            # 输出old tag信息
            # print(values[i][0].to_string())
            new_tag_str = values[i][0].to_string_for_new_tag()
            new_tag_strs.append(new_tag_str)  # 生成new_tag的string信息
        count_dict = Counter(new_tag_strs)  # 统计每一个new_tag出现的次数
        # 生成pos=i时的new_tag = [ref_id, pos, ref_base, read_base, tag_type, is_covered, base_from, support_num]
        pos_new_tag = []
        for key1, value1 in count_dict.items():  # key1: tag string, value1: support_num
            #print('key1:',key1.split( " "))
            if len(key1.split(" "))>7:
                continue
            ref_id, this_pos, ref_base, read_base, tag_type, is_covered, base_from = key1.split(" ")
            if value1 >= 3:
                a_new_tag = NewTag(ref_id, this_pos, ref_base, read_base, tag_type, is_covered, base_from, value1)
                pos_new_tag.append(a_new_tag)
            else:
                continue
        new_tag_dict[pos] = pos_new_tag
    # 显示new_tag_dict = {pos i:[new_tag1,new_tag2, ... ],...}, new_tag = [chr20 69296 G G ref_homo False base_from 22]
    # for key2, value2 in new_tag_dict.items():
    #     for i in range(len(value2)):
    #         print(str(key2) + ":" + value2[i].to_string())
    return new_tag_dict


def preprocess_new_tag(tag_all_sigs_dict):
    """
    preprocess new tag, change it into {pos: {tag_type : [new_tag1, new_tag2, ...],...},...}
    """
    # generate new tags
    new_tag_dict = generate_new_tag(tag_all_sigs_dict)
    type_dict_all = {}
    # new_tag_dict = {pos i:[new_tag1,new_tag2, ... ],...}
    for key1 in new_tag_dict.keys():  # key1 : pos,  value1: [new_tag1,new_tag2, ... ]
        value1 = new_tag_dict[key1]
        ref_gap_tag = []
        ref_hete_tag = []
        read_gap_tag = []
        read_homo_tag = []
        ref_homo_tag = []
        type_dict = {}
        # ################有待优化##############
        for i in range(len(value1)):
            # print(value1[i].to_string())
            if value1[i].tag_type == "ref_homo":
                ref_homo_tag.append(value1[i])
                # continue
            elif value1[i].tag_type == "ref_gap":
                ref_gap_tag.append(value1[i])
            elif value1[i].tag_type == "ref_hete":
                ref_hete_tag.append(value1[i])
            elif value1[i].tag_type == "read_gap":
                read_gap_tag.append(value1[i])
            elif value1[i].tag_type == "read_homo":
                read_homo_tag.append(value1[i])
            else:
                continue
        # if len(ref_homo_tag) != 0:
        #     type_dict["ref_homo"] = ref_homo_tag
        if len(ref_gap_tag) != 0:
            type_dict["ref_gap"] = ref_gap_tag
        if len(ref_hete_tag) != 0:
            type_dict["ref_hete"] = ref_hete_tag
        if len(read_gap_tag) != 0:
            type_dict["read_gap"] = read_gap_tag
        if len(read_homo_tag) != 0:
            type_dict["read_homo"] = read_homo_tag
        type_dict_all[key1] = type_dict
    # 显示type_dict_all = {pos: {tag_type : [new_tag1, new_tag2, ...],...},...}
    # for pos, tag_types_dict in type_dict_all.items():
    #     for tag_type, tags in tag_types_dict.items():
    #         for i in tags:
    #             print("{0} : {1} : {2}".format(pos, tag_type, i.to_string()))
    return type_dict_all


def find_discontinuity(tag_sigs_list):
    """
    Find the discontinuity of a tag_type
    input: tag_sigs_list = [tag1,tag2,...]
    output: [[tag1,tag2],[tag3,...],...]
    """
    time1 = time.time()
    pos_list = []
    for i in range(len(tag_sigs_list)):
        pos_list.append(int(tag_sigs_list[i].pos))
    pos_list = list(set(pos_list))  # 去除重复元素
    pos_list.sort()
    interval_list = []
    t1 = []
    # 找到列表中的连续元素
    for index in range(len(pos_list)):
        t1.append(pos_list[index])
        if int(pos_list[index]) + 1 not in pos_list:
            this_interval = [t1[0], t1[-1]]  # 记录start和end
            interval_list.append(this_interval)
            t1 = []
    time2 = time.time()
    # print("t1:", time2 - time1)
    # 根据interval的区间  记录tag信息
    record_sigs = []
    for i in range(len(interval_list)):
        start = interval_list[i][0]
        end = interval_list[i][1]
        tmp_record = []
        for j in range(len(tag_sigs_list)):
            if start <= int(tag_sigs_list[j].pos) <= end:
                tmp_record.append(tag_sigs_list[j])
        record_sigs.append(tmp_record)
    time3 = time.time()
    # print("t2:", time3 - time2)
    return record_sigs


def cluster_interval(type_dict_all):
    """
    count interval, and return {tag_type1:[[tag1,tag2,...],[tag1,tag2,tag3...],...],tag_type2:...}
    input: type_dict_all: {pos: {tag_type : [new_tag1, new_tag2, ...],...},...}
    step:
        1- 找到几种tag_type所对应的不同pos的所有tag信息 {tag_type1:[tag1,tag2,...],...}
        2- 根据tag信息里面的pos，找到最长不连续字串，实现聚类，记录成{tag_type1:[[tag1,tag2,...],[tag1,tag2,tag3...],...],tag_type2:...}
    """
    record_interval_all = {}
    ref_gap_list = [[] for i in range(2)]
    ref_hete_list = [[] for i in range(2)]
    read_gap_list = [[] for i in range(2)]
    read_homo_list = [[] for i in range(2)]
    # step1: 找到几种tag_type所对应的不同pos的所有tag信息 {tag_type1:[tag1,tag2,...],...}
    for key1, value1 in type_dict_all.items():  # key1: pos, value1: {tag_type : [new_tag1, new_tag2, ...],...}
        for key2, value2 in value1.items():  # key2: tag_type, value2: [new_tag1, new_tag2, ...]
            for i in range(len(value2)):
                tag = value2[i]
                if key2 == "ref_gap":
                    if tag.base_from == "":
                        ref_gap_list[0].append(tag)
                    else:
                        ref_gap_list[1].append(tag)
                elif key2 == "ref_hete":
                    if tag.base_from == "":
                        ref_hete_list[0].append(tag)
                    else:
                        ref_hete_list[1].append(tag)
                elif key2 == "read_gap":
                    if tag.base_from == "":
                        read_gap_list[0].append(tag)
                    else:
                        read_gap_list[1].append(tag)
                elif key2 == "read_homo":
                    if tag.base_from == "":
                        read_homo_list[0].append(tag)
                    else:
                        read_homo_list[1].append(tag)
                else:
                    continue

    # 处理ref_gap_list[1]，区分里面的不同coverage
    coverage_list = []
    for tag_i in ref_gap_list[1]:
        if tag_i.count not in coverage_list:
            coverage_list.append(tag_i.count)
    record_ref_gap_value = []
    for i in range(len(coverage_list)):
        ref_gap_cover_list = []
        for tag in ref_gap_list[1]:
            if tag.count == coverage_list[i]:
                ref_gap_cover_list.append(tag)
        record_ref_gap_value.append(find_discontinuity(ref_gap_cover_list))
    record_ref_gap_value.append(find_discontinuity(ref_gap_list[0]))
    # 此时ref_gap对应的value为[[没有base from],[有base from + coverage 1 ],[有base from + coverage 2 ],...]
    record_interval_all["ref_gap"] = record_ref_gap_value


    # step2: 根据tag信息里面的pos，找到最长不连续字串，实现聚类，记录成
    # {tag_type1: [[[tag1, tag2, ...], [tag1, tag2, tag3...], ...],[]], tag_type2: ...}
    # tag_type包含2类[tag_type有base from的，tag_type没有base from的]
    #record_interval_all["ref_gap"] = [find_discontinuity(ref_gap_list[0]), find_discontinuity(ref_gap_list[1])]
    record_interval_all["ref_hete"] = [find_discontinuity(ref_hete_list[0]), find_discontinuity(ref_hete_list[1])]
    record_interval_all["read_gap"] = [find_discontinuity(read_gap_list[0]), find_discontinuity(read_gap_list[1])]
    record_interval_all["read_homo"] = [find_discontinuity(read_homo_list[0]), find_discontinuity(read_homo_list[1])]

    # 显示record_interval_all
    # for tag_type, interval_list in record_interval_all.items():
    #     for i in range(len(interval_list)):
    #         for j in range(len(interval_list[i])):
    #             for k in range(len(interval_list[i][j])):
    #                 print(1111111)
    #                 print(interval_list[i][j][k].to_string())
    #                 print(2222222)
            # if interval_list[i][j].tag_type == "read_gap":
            #     print("{0}:{1}-{2}".format(tag_type, interval_list[i][0].pos, interval_list[i][-1].pos))
    # print(11111111111111)
    # print(record_interval_all)
    # print(222222222222)
    return record_interval_all
