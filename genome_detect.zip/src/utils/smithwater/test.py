
from Bio import Align
aligner = Align.PairwiseAligner()

alignments = aligner.align("ATCTGTTACTTGCAAGAAACACACTTCACCTACAATGATACACATTGACTTAAAATAAAGGGAT", "ATCTGTTACTTGCAAGAAACACACTTCATTGTAGGTGATACACATTGACTTAAAATAAAGGGAT")

for alignment in sorted(alignments):
    print("Score = %.1f:" % alignment.score)
    print(alignment)