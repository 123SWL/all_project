import os

path = 'C:/Users/Ye_lab/Downloads/fastq-ccs/'

for file in os.listdir(path):
    if 'md5' in file:
        continue
    else:
        os.system('md5sum {0} > {1}'.format(os.path.join(path, file), os.path.join(path, file + '.txt')))

        # check
        for line in open(os.path.join(path, file + '.md5')):
            line_split = line.strip().split('\t')
            origin_md5 = line_split[0]

        for line in open(os.path.join(path, file + '.txt')):
            line_split = line.strip().split('\t')
            check_md5 = line_split[0]

        if check_md5 != origin_md5:
            print(file)

