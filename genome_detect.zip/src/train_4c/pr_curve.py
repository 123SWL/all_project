from sklearn.metrics import precision_recall_curve, roc_curve
import matplotlib.pyplot as plt
import numpy as np

plt.rc('font', family='Times New Roman')
plt.rcParams['font.size'] = 10.5
# 在测试集上评估模型
# model.eval()
# model.to('cpu')
# pred_list = torch.tensor([])
# with torch.no_grad():
#     for X, y in test_iter:
#         pred = model(X)
#         pred_list = torch.cat([pred_list, pred])
#
# test_iter1 = data.DataLoader(test_data, batch_size=10000, shuffle=False,
#                              num_workers=2)
# features, labels = next(iter(test_iter1))
# print(labels.shape)
#
#
# #输出每个类别的精确率和召回率
# train_result = np.zeros((10, 10), dtype=int)
# for i in range(len(test_data)):
#     train_result[labels[i]][np.argmax(pred_list[i])] += 1
# result_table = prettytable.PrettyTable()
# result_table.field_names = ['Type', 'Accuracy(精确率)', 'Recall(召回率)', 'F1_Score']
# class_names = ['Zero', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine']
# for i in range(10):
#     accuracy = train_result[i][i] / train_result.sum(axis=0)[i]
#     recall = train_result[i][i] / train_result.sum(axis=1)[i]
#     result_table.add_row([class_names[i], np.round(accuracy, 3), np.round(recall, 3),
#                           np.round(accuracy * recall * 2 / (accuracy + recall), 3)])
# print(result_table)
#
# # 采用scikit-learn模块对10个类分别绘制PR曲线和ROC曲线
# #from sklearn.metrics import precision_recall_curve, roc_curve
#
# for i in range(10):
#     temp_true = []
#     temp_probilities = []
#     temp = 0
#
#     for j in range(len(labels)):
#         if i == labels[j]:
#             temp = 1
#         else:
#             temp = 0
#         temp_true.append(temp)
#         temp_probilities.append(pred_probilities[j][i])
#
#     precision, recall, threshholds = precision_recall_curve(temp_true, temp_probilities)
#     fpr, tpr, thresholds = roc_curve(temp_true, temp_probilities)
#
#     plt.figure(figsize=(12, 6))
#     plt.subplot(1, 2, 1)
#     plt.xlabel('Precision')
#     plt.ylabel('Recall')
#     plt.title(f'Precision & Recall Curve (class:{i}) ')
#     plt.plot(precision, recall, 'yellow')
#
#     plt.subplot(1, 2, 2)
#     plt.xlabel('Fpr')
#     plt.ylabel('Tpr')
#     plt.title(f'Roc Curve (class:{i})')
#     plt.plot(fpr, tpr, 'cyan')
#     plt.show()

# image_save_path = "/mnt/e/CCSVar2.0/model_record/pic/"
# score_path = "/mnt/e/CCSVar2.0/pr/pr_test_1.txt"  # 文件路径
image_save_path = "E:\\CCSVar2.0\\model_record\\pic\\"
score_path = "E:\\CCSVar2.0\\pr\\pr_test_1.txt"
with open(score_path, 'r') as f:
    files = f.readlines()      # 读取文件

lis_all = []
for file in files:
    _, _, s1, s2, s3,s4,s5,s6 = file.strip().split(" ")
    lis_all.append(s1)
    lis_all.append(s2)
    lis_all.append(s3)
    lis_all.append(s4)
    lis_all.append(s5)
    lis_all.append(s6)
lis_order = sorted(set(lis_all))   # 记录所有得分情况，并去重从小到大排序，寻找各个阈值点

macro_precis = []
macro_recall = []
macro_precis_del=[]
macro_recall_del=[]
macro_precis_snp=[]
macro_recall_snp=[]
macro_precis_inv=[]
macro_recall_inv=[]
macro_precis_ins=[]
macro_recall_ins=[]
macro_precis_dup=[]
macro_recall_dup=[]
macro_precis_invdup=[]
macro_recall_invdup=[]


for i in lis_order:

    true_p0 = 0         # 真阳
    true_n0 = 0         # 真阴
    false_p0 = 0        # 假阳
    false_n0 = 0        # 假阴

    true_p1 = 0
    true_n1 = 0
    false_p1 = 0
    false_n1 = 0

    true_p2 = 0
    true_n2 = 0
    false_p2 = 0
    false_n2 = 0


    true_p3 = 0
    true_n3 = 0
    false_p3 = 0
    false_n3 = 0

    true_p4 = 0
    true_n4 = 0
    false_p4 = 0
    false_n4 = 0

    true_p5 = 0
    true_n5 = 0
    false_p5 = 0
    false_n5 = 0
    for file in files:
        cls, pd, n0, n1, n2, n3, n4, n5 = file.strip().split(" ")       # 分别计算比较各个类别的得分，分开计算，各自为二分类，
                                                                        # 最后求平均，得出宏pr

        if float(n0) >= float(i) and cls == '0':               # 遍历所有样本，第0类为正样本，其他类为负样本，
            true_p0 = true_p0 + 1                              # 大于等于阈值，并且真实为正样本，即为真阳，
        elif float(n0) >= float(i) and cls != '0':             # 大于等于阈值，真实为负样本，即为假阳；
            false_p0 = false_p0 + 1                            # 小于阈值，真实为正样本，即为假阴
        elif float(n0) < float(i) and cls == '0':
            false_n0 = false_n0 + 1

        if float(n1) >= float(i) and cls == '1':                # 遍历所有样本，第1类为正样本，其他类为负样本
            true_p1 = true_p1 + 1
        elif float(n1) >= float(i) and cls != '1':
            false_p1 = false_p1 + 1
        elif float(n1) < float(i) and cls == '1':
            false_n1 = false_n1 + 1

        if float(n2) >= float(i) and cls == '2':                # 遍历所有样本，第2类为正样本，其他类为负样本
            true_p2 = true_p2 + 1
        elif float(n2) >= float(i) and cls != '2':
            false_p2 = false_p2 + 1
        elif float(n2) < float(i) and cls == '2':
            false_n2 = false_n2 + 1


        if float(n3) >= float(i) and cls == '3':                # 遍历所有样本，第3类为正样本，其他类为负样本
            true_p3 = true_p3 + 1
        elif float(n3) >= float(i) and cls != '3':
            false_p3 = false_p3 + 1
        elif float(n3) < float(i) and cls == '3':
            false_n3 = false_n3 + 1



        if float(n4) >= float(i) and cls == '4':                # 遍历所有样本，第4类为正样本，其他类为负样本
            true_p4 = true_p4 + 1
        elif float(n4) >= float(i) and cls != '4':
            false_p4 = false_p4 + 1
        elif float(n4) < float(i) and cls == '4':
            false_n4 = false_n4 + 1


        if float(n5) >= float(i) and cls == '5':                # 遍历所有样本，第5类为正样本，其他类为负样本
            true_p5 = true_p5 + 1
        elif float(n5) >= float(i) and cls != '5':
            false_p5 = false_p5 + 1
        elif float(n5) < float(i) and cls == '5':
            false_n5 = false_n5 + 1


    prec0 = (true_p0+0.00000000001) / (true_p0 + false_p0 + 0.00000000001)      # 计算各类别的精确率，小数防止分母为0
    prec1 = (true_p1+0.00000000001) / (true_p1 + false_p1 + 0.00000000001)
    prec2 = (true_p2+0.00000000001) / (true_p2 + false_p2 + 0.00000000001)
    prec3 = (true_p3+0.00000000001) / (true_p3 + false_p3 + 0.00000000001)      # 计算各类别的精确率，小数防止分母为0
    prec4 = (true_p4+0.00000000001) / (true_p4 + false_p4 + 0.00000000001)
    prec5 = (true_p5+0.00000000001) / (true_p5 + false_p5 + 0.00000000001)



    recall0 = (true_p0+0.00000000001)/(true_p0+false_n0 + 0.00000000001)        # 计算各类别的召回率，小数防止分母为0
    recall1 = (true_p1+0.00000000001) / (true_p1 + false_n1+0.00000000001)
    recall2 = (true_p2+0.00000000001)/(true_p2+false_n2 + 0.00000000001)
    recall3 = (true_p3+0.00000000001)/(true_p3+false_n3 + 0.00000000001)        # 计算各类别的召回率，小数防止分母为0
    recall4 = (true_p4+0.00000000001) / (true_p4 + false_n4+0.00000000001)
    recall5 = (true_p5+0.00000000001)/(true_p5+false_n5 + 0.00000000001)


    precision = (prec0 + prec1 + prec2+prec3 + prec4 + prec5)/6
    recall = (recall0 + recall1 + recall2+recall3 + recall4 + recall5)/6               # 多分类求得平均精确度和平均召回率，即宏macro_pr
    macro_precis.append(precision)
    macro_recall.append(recall)
    macro_precis_del.append(prec2)
    macro_recall_del.append(recall2)
    macro_precis_snp.append(prec0)
    macro_recall_snp.append(recall0)
    macro_precis_inv.append(prec3)
    macro_recall_inv.append(recall3)
    macro_precis_ins.append(prec1)
    macro_recall_ins.append(recall1)
    macro_precis_dup.append(prec4)
    macro_recall_dup.append(recall4)
    macro_precis_invdup.append(prec5)
    macro_recall_invdup.append(recall5)


macro_precis.append(1)
macro_recall.append(0)
# print(macro_precis)
# print(macro_recall)
macro_precis_del.append(1)
macro_recall_del.append(0)
macro_precis_dup.append(1)
macro_recall_dup.append(0)
macro_precis_ins.append(1)
macro_recall_ins.append(0)
macro_precis_inv.append(1)
macro_recall_inv.append(0)
macro_precis_invdup.append(1)
macro_recall_invdup.append(0)
macro_precis_snp.append(1)
macro_recall_snp.append(0)


x0 = np.array(macro_recall_snp)
y0 = np.array(macro_precis_snp)
x1 = np.array(macro_recall_ins)
y1 = np.array(macro_precis_ins)
x2 = np.array(macro_recall_del)
y2 = np.array(macro_precis_del)
x3 = np.array(macro_recall_inv)
y3 = np.array(macro_precis_inv)
x4 = np.array(macro_recall_dup)
y4 = np.array(macro_precis_dup)
x5 = np.array(macro_recall_invdup)
y5= np.array(macro_precis_invdup)
x = np.array(macro_recall)
y = np.array(macro_precis)
# plt.figure()
# plt.xlim([-0.01, 1.01])
# plt.ylim([-0.01, 1.01])
# plt.xlabel('recall')
# plt.ylabel('precision')
# plt.title('PR curve')
# plt.plot(x, y)
# plt.show()
# plt.savefig(image_save_path + "PR.png")
plt.figure()
plt.grid()
# plt.rcParams['font.family'] = ['serif']
# plt.rcParams['font.serif'] = ['Times New Roman'] + plt.rcParams['font.serif']
# plt.rcParams['font.size'] = 10.5
plt.title('Precision & Recall Curve')
plt.rcParams['figure.figsize'] = (10.0, 10.0)
plt.rcParams['image.interpolation'] = 'nearest'
plt.rcParams['image.cmap'] = 'gray'
#plt.rcParams['font.sans-serif']=['SimHei']
#plt.rcParams['axes.unicode_minus']=False
# 设置标题大小


plt.plot(x, y, 'b',linewidth=2,linestyle='-')
# plt.plot(x1, y1, color='grey',linestyle='-.',marker='p',linewidth=4,label=u'ins')
# plt.plot(x2, y2, color='b',linestyle=':',linewidth=5,marker
# ',label=u'del')
# plt.plot(x3, y3, color='red',linestyle='--',linewidth=6,marker='D',label=u'inv')
# plt.plot(x4, y4, color='r',linestyle='-',linewidth=2,label=u'dup')
# plt.plot(x5, y5, color='cyan',linestyle='-.',linewidth=7,label=u'invdup')

plt.legend(loc='lower right')
#plt.plot([0,1],[0,1],'r--')
plt.xlim([-0.1,1.1])
plt.ylim([-0.1,1.1])
plt.ylabel('Precision')
plt.xlabel('Racall')
plt.grid(linestyle='-.')
#plt.grid(True)
plt.show()
plt.savefig(image_save_path + "all_pr_all_test.png")