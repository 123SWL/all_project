from __future__ import print_function
import matplotlib.pyplot as plt
from create_batch_test import BatchGeneratorTest
from create_batch_train import BatchGenerator
import tensorflow as tf
import numpy as np
import cv2
import os
import re
import string
import os.path

###打乱顺序的代码





# import random
#
# out_file = open('/mnt/e/data/visor_data/train_data/train2_new.txt', 'w', encoding='utf-8')  # 输出文件位置
#
# lines = []
#
# with open('/mnt/e/data/visor_data/train_data/train2.txt', 'r', encoding='utf-8') as f:  # 需要打乱的原文件位置
#     for line in f:
#         lines.append(line)
# random.shuffle(lines)
#
# for line in lines:
#     out_file.write(line)
#
# out_file.close()


##生成测试文件的代码

# work_path = "/mnt/f/vcf/hg00733/image/vcf/hg00733"
# #work_path = "E:\\data\\chr20\\output\\encode_4c\\test\\dup\\image"
# # work_path = "E:\\project\\CCSVar\\dataset\\encode_4c\\error_50\\test"
# # # train and test dataset path
# out_path = "/mnt/e/data/visor_data/train_data/test"
# out_file = open(os.path.join(out_path, 'test_sjj_real_chr20.txt'), 'w')
# for file in os.listdir(work_path):
#     # if 'png' not in file:
#     #     continue
#     if '_show' in file:
#         continue
#     out_file.write('{0}\n'.format(os.path.join(work_path, file)))
# out_file.close()
# print("Finished generate image file")
#print(''.join(sorted(open('/mnt/e/data/visor_data/train_data/test/test_sjj_real.txt'), key=lambda s: s.split('.')[0])))
# 文本排序并保存
output_file = '/mnt/f/vcf/hg00733/vcf/35.txt'
output_file_sort = '/mnt/f/vcf/hg00733/pr/sort/35.txt'
ditc={}
with open(output_file,'r') as f:
    files=f.readlines()
    for file in files:
        key=int(re.split('[_.]',file)[2])
        #print(key)
        ditc[key]=file
    #print(ditc)
    dir_sort = sorted(ditc.items(), key=lambda x: x[0])
    #print(dir_sort)
with open(output_file_sort,'w') as f1:
    for key,value in dir_sort:
        f1.write(value)
# with open(output_file_sort,'w') as f1:
#     for i in dir_sort:
#         print(dir_sort[i])


