import os
import re
num=[]
del_n,ins_n=0,0
with open(os.path.join('/mnt/f/vcf/h37/data_image/benchmark.bed'), 'r') as bed_file:
    for line in bed_file.readlines():
        curline=(re.split('[(,]',line)[1])
        type=line.split('\t')[3]
        if '-' in curline:
            num.append(int(curline[1:]))
        else:
            num.append(int(curline))
        if type=='DEL':
            del_n+=1
        if type=='INS':
            ins_n+=1
print(del_n)
print(ins_n)

#print(num)
count1,count2,count3,count4,count5=0,0,0,0,0
for i in num:
    if i==1:
        count1+=1
    elif i<50:
        count2+=1
    elif i>=50:
        count3+=1

print(count1)
print(count2)
print(count3)
print(count4)
print(count5)