from alexnet import AlexNet
import os
import numpy as np
import tensorflow as tf
from datetime import datetime
from alexnet import AlexNet
from create_batch_train import BatchGenerator
import matplotlib.pyplot as plt
import random
from tensorflow.python.keras.models import Model,load_model

from tensorflow.python.keras.utils import np_utils
from sklearn import manifold
from tensorflow.python.keras.callbacks import ReduceLROnPlateau
import matplotlib as mpl
from tensorflow.python.keras.models import Model

def seed_tensorflow(seed=42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    tf.set_random_seed(seed)


batch_size=128
num_classes=6
keep_prob=0.5
train_file = '/mnt/e/data/visor_data/train_data/train2_new.txt'
val_file = '/mnt/e/data/visor_data/train_data/valid2_new.txt'

x = tf.placeholder(tf.float32, [None, 5, 64, 4], name="x")
y = tf.placeholder(tf.float32, [None, num_classes], name="y")

model = AlexNet(x, keep_prob, num_classes)
score = model.fc8
tf.add_to_collection("score", score)

# List of trainable variables of the layers we want to train
# var_list = [v for v in tf.trainable_variables() if v.name.split('/')[0] in train_layers]
var_list = [v for v in tf.trainable_variables()]

# add L1,L2 regularization
W = tf.get_variable('weight', shape=[5, 64, 4], initializer=tf.ones_initializer())
tf.add_to_collection(tf.GraphKeys.WEIGHTS, W)
regularizer = tf.contrib.layers.l2_regularizer(0.001)
reg_term = tf.contrib.layers.apply_regularization(regularizer)
train_generator = BatchGenerator(train_file, type="train", scale_size=(5, 64),
                                 horizontal_flip=True, shuffle=True, nb_classes=num_classes, gaussion_noise=False)
val_generator = BatchGenerator(val_file, type="train", scale_size=(5, 64), shuffle=False, nb_classes=num_classes,
                               gaussion_noise=False)

# Get the number of training/validation steps per epoch
train_batches_per_epoch = np.floor(train_generator.data_size / batch_size).astype(np.int16)

val_batches_per_epoch = np.floor(val_generator.data_size / batch_size).astype(np.int16)
model=load_model('/mnt/e/CCSVar2.0/model_record/checkpoints/2023-02-15T14-38-05/model_epoch5.ckpt')

model.summary()

ts = manifold.TSNE(n_components=2, init='pca', random_state=0)