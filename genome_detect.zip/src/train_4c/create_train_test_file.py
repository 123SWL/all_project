import os
from collections import Counter

# image path
a = 'image6'
#work_path = '/mnt/e/data/visor_data/train_data/{0}'.format(a)
work_path = '/mnt/e/CCS/data/var_data/perfect/test/{0}'.format(a)
# train and test dataset path
#out_path = '/mnt/e/data/visor_data/train_data/'
out_path = '/mnt/e/CCS/data/var_data/perfect/test/'
out_file = open(os.path.join(out_path, '{0}.txt'.format(a)), 'w')
sv_types = []

for file in os.listdir(work_path):
    if 'png' not in file:
        continue
    if 'show' in file:
        continue
    # if '-' in file:
    #     continue
    #print(file.split('.')[0].split('-')[1])

    sv_type = file.split('.')[0].split('-')[1]

    # if sv_type == 'REF':
    #      label = 0
    # if sv_type == 'SNPAT':
    #     label = 0
    # elif sv_type == 'SNPAG':
    #     label = 1
    # elif sv_type == 'SNPAC':
    #     label = 2
    # elif sv_type == 'SNPTA':
    #     label = 3
    # #elif sv_type == 'SNPTC' or sv_type == 'tDUP':
    # elif sv_type == 'SNPTC':
    #     label = 4
    # elif sv_type == 'SNPTG':
    #     label = 5
    # elif sv_type == 'SNPCG':
    #     label = 6
    # elif sv_type == 'SNPCT':
    #     label = 7
    # elif sv_type == 'SNPCA':
    #     label = 8
    # elif sv_type == 'SNPGA':
    #     label = 9
    # elif sv_type == 'SNPGT':
    #     label = 10
    # elif sv_type == 'SNPGC':
    #     label = 11
    # if sv_type == 'REF':
    #     label = 0
    if sv_type == 'SNP':
        label = 0
    elif sv_type == 'INS':
        label = 1
    elif sv_type == 'DEL':
        label = 2
    elif sv_type == 'INV':
        label = 3
    elif sv_type == 'DUP' or sv_type == 'tDUP':
        label = 4
    elif sv_type == 'invDUP':
        label = 5
    else:
        continue




    out_file.write('{0}  {1}\n'.format(os.path.join(work_path, file), label))