from __future__ import print_function
import matplotlib.pyplot as plt
from create_batch_test import BatchGeneratorTest
from create_batch_train import BatchGenerator
import tensorflow as tf
import numpy as np
import cv2
import os
from sklearn.metrics import precision_recall_curve, roc_curve
#import numpy as np
#import tensorflow as tf
from alexnet import AlexNet
from create_batch_train import BatchGenerator




# generate image file
def generate_img_file(work_path, out_path):
    out_file = open(os.path.join(out_path, 'test_real_s.txt'), 'w')
    for file in os.listdir(work_path):
        if 'png' not in file:
            continue
        if 'show' in file:
            continue
        out_file.write('{0}\n'.format(os.path.join(work_path, file)))
    out_file.close()
    print("Finished generate image file")


# image path
work_path = "/mnt/e/data/output/encode_4c/test/image"
#work_path = "/mnt/e/data/visor_data/train_data/valid2_del"
#work_path = "E:\\data\\chr20\\output\\encode_4c\\test\\dup\\image"
# work_path = "E:\\project\\CCSVar\\dataset\\encode_4c\\error_50\\test"
# # train and test dataset path
out_path = "/mnt/e/data/visor_data/train_data/test"
#out_path = "E:\\data\\chr20\\output\\encode_4c\\test\\dup\\test"
# out_path = "E:\\data\\chr20\\output\\encode_4c\\test\\inv_ins\\test"
generate_img_file(work_path, out_path)
#test_file = "E:\\data\\chr20\\output\\encode_4c\\test\\dup\\test\\test_zyh.txt"
#test_file = "/mnt/e/data/visor_data/train_data/valid2_del.txt"
test_file = "/mnt/e/data/visor_data/train_data/test/test_sjj_real.txt"
# model path
model_path = "/mnt/e/CCSVar2.0/model_record/checkpoints/2023-02-24T15-37-36/"
#model_path = "/mnt/e/CCS/record3/record3/checkpoints/2021-08-09T21-15-58/"
#model_path = "E:\\project\\CCSVar\\model_record\\model_vcf_data\\record3\\checkpoints\\2021-08-09T21-15-58\\"
meta_path = model_path + "model_epoch6.ckpt.meta"
ckpt_path = model_path + "model_epoch6.ckpt"
log_dir = model_path + "test"
#out_file = "E:\\data\\chr20\\output\\encode_4c\\test\\dup\\result\\result_vcf\\record3\\"
out_file = "/mnt/e/CCS/chr20/output/encode_4c/test/dup/result/result_vcf/record_true_new_2021/"
# parameters
batch_size = 64
num_classes = 6
dropout_rate = 0.5
train_layers = ['fc8', 'fc7', 'fc6']



def show_pic(img, maxx, prob):
    image = np.reshape(img, (5, 64, 4))
    text = 'Predicted class:' + str(maxx)
    cv2.putText(image, text, (20, 20), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.putText(image, 'with probability:' + str(prob), (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.imshow('test_image', image)
    k = cv2.waitKey(0)  # waitKey代表读取键盘的输入，0代表一直等待
    if k == 27:  # 键盘上Esc键的键值
        cv2.destroyAllWindows()


def write_pic(img, maxx, prob, count, out_file):
    # plot for show
    plt.subplot(411)
    plt.imshow(img[:, :, 0])
    plt.yticks([])

    plt.subplot(412)
    plt.imshow(img[:, :, 1])
    plt.yticks([])

    plt.subplot(413)
    plt.imshow(img[:, :, 2])
    plt.yticks([])

    plt.subplot(414)
    plt.imshow(img[:, :, 3])
    plt.yticks([])
    plt.savefig(os.path.join(out_file, '{0}_{1:.4f}_{2}_show.png'.format(maxx, prob, count)))

x = tf.placeholder(tf.float32, [batch_size, 5, 64, 4])
y = tf.placeholder(tf.float32, [num_classes])
keep_prob = tf.placeholder(tf.float32)

# Initialize model_ft
model = AlexNet(x, keep_prob, num_classes)

# Link variable to model_ft output
score = model.fc8

# create batch iterator
test_generator = BatchGeneratorTest(class_list=test_file, type="test", scale_size=(5, 64))
#print(test_generator)
test_batches_per_epoch = np.floor(test_generator.data_size / batch_size).astype(np.int16)

#pre_generator = BatchGenerator(self.predict_file, type="train", shuffle=True, nb_classes=self.num_classes)

with tf.name_scope("accuracy"):
    correct_pred = tf.equal(tf.argmax(score, 1), tf.argmax(y, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

val_batches_per_epoch = np.floor(test_generator.data_size / batch_size).astype(np.int16)
saver = tf.train.Saver()
# Start Tensorflow session
with tf.Session() as sess:
    # Initialize all variables
    model_path = '/mnt/e/CCSVar2.0/model_record/checkpoints/2023-02-15T14-38-05/model_epoch5.ckpt'
    sess.run(tf.global_variables_initializer())
    saver.restore(sess, (model_path))
    sess.run(tf.local_variables_initializer())
    test_acc = 0.
    test_count = 0
    for _ in range(val_batches_per_epoch):

        batch_tx= test_generator.next_batch(batch_size)
        # print(batch_ty)

        # print(batch_ty)

        score_value, acc_value, softmax = sess.run([score, accuracy, tf.nn.softmax(score)], feed_dict={x: batch_tx, keep_prob: dropout_rate})
        # print(score_value)
        # print(softmax)
        print(np.argmax(score_value, axis=1), acc_value)

# with tf.Session() as sess:
#     saver = tf.train.import_meta_graph(meta_path)  # 加载图结构
#     # saver.restore(sess, tf.train.latest_checkpoint(model_path))  # 加载变量值
#     saver.restore(sess, ckpt_path)
#     graph = tf.get_default_graph()  # 获取当前图，为了后续训练时恢复变量
#     tensor_name_list = [tensor.name for tensor in graph.as_graph_def().node]  # 得到当前图中所有变量的名称
#     test_writer = tf.summary.FileWriter(log_dir + '/test')
#     x = graph.get_operation_by_name("x").outputs[0]
#     keep_prob = graph.get_operation_by_name("keep_prob").outputs[0]
#     score = tf.get_collection("score")
#     softmax = tf.nn.softmax(score)
#     print('finish loading model!')
#
#     # feed data
#     pred_yy = []
#     pred_score=[]
#     prob_list = []
#     true_yy=[]
#     step = 0
#     to_list=[]
#     while step < test_batches_per_epoch:
#         #print(step)
#         batch_xs = test_generator.next_batch(batch_size)
#         image = batch_xs[0]
#         score_y, soft = sess.run([score, softmax], feed_dict={x: batch_xs, keep_prob: 1.})
#        # score_value, acc_value, softmax = sess.run([score, accuracy, tf.nn.softmax(score)],feed_dict={x: batch_tx, y: batch_ty, keep_prob: self.dropout_rate})
#         soft1=soft.tolist()
#         pred_score.append(soft1)
#         print(soft)
#         maxx = np.argmax(soft)
#         print(maxx)
#         prob = soft[0][0][maxx]
#         print(prob)
#         prob_list.append(prob)
#         pred_yy.append(maxx)
#
#         write_pic(image, maxx, prob, count=step, out_file=out_file)
#         step += 1
#     print("finished!")