"""
With this script you can finetune AlexNet as provided in the alexnet_old.py
class on any given dataset.
Specify the configuration settings at the beginning according to your
problem.
This script was written for TensorFlow 1.0 and come with a blog post
you can find here:

https://kratzert.github.io/2017/02/24/finetuning-alexnet-with-tensorflow.html
Author: Frederik Kratzert
contact: f.kratzert(at)gmail.com
"""
import os
import numpy as np
import tensorflow as tf
from datetime import datetime
from alexnet import AlexNet
from create_batch_train import BatchGenerator

"""
Configuration settings
"""

# Path to the textfiles for the trainings and validation set
train_file = '/mnt/e/data/visor_data/train_data/train2.txt'
val_file = '/mnt/e/data/visor_data/train_data/valid2.txt'

# Learning params
#learning_rate = 1e-2
num_epochs = 100
batch_size = 128
# Network params
dropout_rate = 0.5
num_classes = 12
# train_layers = ['fc8', 'fc7', 'fc6']

# How often we want to write the tf.summary data to disk
display_step = 10

# Path for tf.summary.FileWriter and to store model_ft checkpoints
filewriter_path = "/mnt/e/CCSVar2.0/model_record/log/"  # tensorboard 地址
checkpoint_path = "/mnt/e/CCSVar2.0/model_record/checkpoints/"
out_file = open("/mnt/e/CCSVar2.0/model_record/record.txt", "w")


# Create parent path if it doesn't exist
if not os.path.isdir(checkpoint_path):
    os.mkdir(checkpoint_path)

# TF placeholder for graph input and output
x = tf.placeholder(tf.float32, [batch_size, 5, 64, 4])
y = tf.placeholder(tf.float32, [None, num_classes])
keep_prob = tf.placeholder(tf.float32)

# Initialize model_ft
model = AlexNet(x, keep_prob, num_classes)

# Link variable to model_ft output
score = model.fc8

# List of trainable variables of the layers we want to train
# var_list = [v for v in tf.trainable_variables() if v.name.split('/')[0] in train_layers]
var_list = [v for v in tf.trainable_variables()]
# Op for calculating the loss
with tf.name_scope("cross_ent"):
    loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=score, labels=y))

# Train op
with tf.name_scope("train"):
    # Get gradients of all trainable variables
    gradients = tf.gradients(loss, var_list)
    gradients = list(zip(gradients, var_list))

    # Create optimizer and apply gradient descent to the trainable variables
    optimizer = tf.train.GradientDescentOptimizer(learning_rate)
    train_op = optimizer.apply_gradients(grads_and_vars=gradients)

# Add gradients to summary
for gradient, var in gradients:
    tf.summary.histogram(var.name + '/gradient', gradient)

# Add the variables we train to the summary
for var in var_list:
    tf.summary.histogram(var.name, var)

# Add the loss to summary
tf.summary.scalar('cross_entropy', loss)

# Evaluation op: Accuracy of the model_ft
with tf.name_scope("accuracy"):
    correct_pred = tf.equal(tf.argmax(score, 1), tf.argmax(y, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

# Add the accuracy to the summary
tf.summary.scalar('accuracy', accuracy)

# Merge all summaries together
merged_summary = tf.summary.merge_all()

# Initialize the FileWriter
writer = tf.summary.FileWriter(filewriter_path)

# Initialize an saver for store model_ft checkpoints
saver = tf.train.Saver(max_to_keep=10000)

# Initalize the data generator seperately for the training and validation set
train_generator = BatchGenerator(train_file, type="train", scale_size=(5, 64),
                                 horizontal_flip=True, shuffle=True, nb_classes=num_classes)
val_generator = BatchGenerator(val_file, type="train", scale_size=(5, 64), shuffle=False, nb_classes=num_classes)

# Get the number of training/validation steps per epoch
train_batches_per_epoch = np.floor(train_generator.data_size / batch_size).astype(np.int16)
val_batches_per_epoch = np.floor(val_generator.data_size / batch_size).astype(np.int16)
# Start Tensorflow session

with tf.Session() as sess:
    # Initialize all variables
    sess.run(tf.global_variables_initializer())

    # Add the model_ft graph to TensorBoard
    writer.add_graph(sess.graph)

    # # Load the pretrained weights into the non-trainable layer
    # model.load_initial_weights(sess)

    print("{} Start training...".format(datetime.now()))
    print("{} Open Tensorboard at --logdir {}".format(datetime.now(),filewriter_path))

    # Loop over number of epochs

    time1 = datetime.now()
    for epoch in range(num_epochs):
        learing_rate_decay = tf.train.exponential_decay(learning_rate=0.1, global_step=300, decay_steps=10,
                                                        decay_rate=0.9, staircase=False)
        learning_rate = sess.run([learing_rate_decay])
        tot_loss = 0

        tot_cnt = 0
        print("{} Epoch number: {}".format(datetime.now(), epoch + 1))

        step = 1

        while step < train_batches_per_epoch:

            # Get a batch of images and labels
            batch_xs, batch_ys = train_generator.next_batch(batch_size)

            # And run the training op
            sess.run(train_op, feed_dict={x: batch_xs,
                                          y: batch_ys,
                                          keep_prob: dropout_rate})

            # Generate summary with the current batch of data and write to file
            if step % display_step == 0:
                loss_val, accuracy_val, s = sess.run([loss, accuracy, merged_summary], feed_dict={x: batch_xs,
                                                                                                  y: batch_ys,
                                                                                                  keep_prob: 1.})
                time2 = datetime.now()
                print(str(epoch) + " " + str(step) + ": " + str(loss_val) + " " + str(accuracy_val) + " " + str(
                    (time2 - time1).seconds))
                tot_cnt += 1
                tot_loss += loss_val
                out_file.write(str(epoch) + " " + str(step) + ": " + str(loss_val) + " " + str(accuracy_val) + "\n")
                writer.add_summary(s, epoch * train_batches_per_epoch + step)
                time1 = datetime.now()
            step += 1

        # Validate the model_ft on the entire validation set
        print("{} Start validation".format(datetime.now()))
        out_file.write("--------------------epoch%d----------------\n" % epoch)
        out_file.write('average loss: ' + str(float(tot_loss / tot_cnt)))
        print('average loss: ', float(tot_loss / tot_cnt))
        out_file.write("{} Start validation\n".format(datetime.now()))

        test_acc = 0.
        test_count = 0
        for _ in range(val_batches_per_epoch):
            batch_tx, batch_ty = val_generator.next_batch(batch_size)
            acc = sess.run(accuracy, feed_dict={x: batch_tx,
                                                y: batch_ty,
                                                keep_prob: 1.})
            # out_file.write(str(acc) + "\n")
            test_acc += acc
            test_count += 1
        test_acc /= test_count
        print("{} Validation Accuracy = {:.4f}".format(datetime.now(), test_acc))
        out_file.write("{} Validation Accuracy = {:.4f}\n".format(datetime.now(), test_acc))

        # Reset the file pointer of the image data generator
        val_generator.reset_pointer()
        train_generator.reset_pointer()

        print("{} Saving checkpoint of model_ft...".format(datetime.now()))

        # save checkpoint of the model_ft
        checkpoint_name = os.path.join(checkpoint_path, 'model_epoch' + str(epoch + 1) + '.ckpt')
        save_path = saver.save(sess, checkpoint_name)

        print("{} Model checkpoint saved at {}".format(datetime.now(), checkpoint_name))

out_file.close()
