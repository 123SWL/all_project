import numpy as np
import tensorflow as tf
from alexnet import AlexNet
from create_batch_train import BatchGenerator

class Validate:
    def __init__(self, in_dir):

        # Path to the textfiles for the trainings and validation set
        self.predict_file ='/mnt/e/CCSVar2.0/TEST/test_new.txt'

        # Network params
        self.dropout_rate = 0.5
        self.num_classes = 6
        self.train_layers = ['fc8', 'fc7', 'fc6']

        self.batch_size = 128



    def run(self):
        x = tf.placeholder(tf.float32, [self.batch_size, 5, 64, 4])
        y = tf.placeholder(tf.float32, [None, self.num_classes])
        keep_prob = tf.placeholder(tf.float32)

        # Initialize model_ft
        model = AlexNet(x, keep_prob, self.num_classes, self.train_layers)

        # Link variable to model_ft output
        score = model.fc8


        pre_generator = BatchGenerator(self.predict_file, type="train", shuffle=True, nb_classes=self.num_classes)

        with tf.name_scope("accuracy"):
            correct_pred = tf.equal(tf.argmax(score, 1), tf.argmax(y, 1))
            accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

        val_batches_per_epoch = np.floor(pre_generator.data_size / self.batch_size).astype(np.int16)
        print(2222222222)

        saver = tf.train.Saver()
        # Start Tensorflow session
        with tf.Session() as sess:
            # Initialize all variables
            model_path = '/mnt/e/CCSVar2.0/model_record/checkpoints/2023-02-15T14-38-05/model_epoch5.ckpt'
            sess.run(tf.global_variables_initializer())
            saver.restore(sess, (model_path))
            sess.run(tf.local_variables_initializer())
            test_acc = 0.
            test_count = 0
            for _ in range(val_batches_per_epoch):

                batch_tx, batch_ty = pre_generator.next_batch(self.batch_size)
                # print(batch_ty)

                # print(batch_ty)

                score_value, acc_value, softmax = sess.run([score, accuracy, tf.nn.softmax(score)], feed_dict={x: batch_tx, y: batch_ty, keep_prob: self.dropout_rate})
                # print(score_value)
                # print(softmax)
                print(np.argmax(batch_ty, axis=1), np.argmax(score_value, axis=1), acc_value)


                test_acc += acc_value
                test_count += 1
            test_acc /= test_count
            print("ave: " + str(test_acc))



in_dir = "/mnt/e/CCSVar2.0/TEST/images"
# in_dir = "D:\\Workspace\\Sv\\train\\733_new\\INS"
validate = Validate(in_dir)
validate.run()