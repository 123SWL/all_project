import numpy as np
import cv2

"""
This code is highly influenced by the implementation of:
https://github.com/joelthchao/tensorflow-finetune-flickr-style/dataset.py
But changed abit to allow data augmentation (yet only horizontal flip) and 
shuffling of the data. 
The other source of inspiration is the ImageDataGenerator by @fchollet in the 
Keras library. But as I needed BGR color format for fine-tuneing AlexNet I 
wrote my own little generator.
"""


class BatchGeneratorTest:
    def __init__(self, class_list, horizontal_flip=False, shuffle=False,
                 mean=np.array([104., 117., 124., 127.]), scale_size=(227, 227), type="test"):

        # Init params
        self.horizontal_flip = horizontal_flip
        self.shuffle = shuffle
        self.mean = mean
        self.scale_size = scale_size
        self.pointer = 0
        self.type = type
        self.read_class_list(class_list)

        if self.shuffle:
            self.shuffle_data()

    def read_class_list(self, class_list):
        """
        Scan the image file and get the image paths
        """
        with open(class_list) as f:
            lines = f.readlines()
            self.images = []
            for line in lines:
                items = line.split()
                self.images.append(items[0])
            # store total number of data
        self.data_size = len(self.images)

    def shuffle_data(self):
        """
        Random shuffle the images
        """
        images = self.images.copy()
        self.images = []

        # create list of permutated index and shuffle data accoding to list
        idx = np.random.permutation(len(images))
        for i in idx:
            self.images.append(images[i])

    def reset_pointer(self):
        """
        reset pointer to begin of the list
        """
        self.pointer = 0

        if self.shuffle:
            self.shuffle_data()

    def next_batch(self, batch_size):
        """
        This function gets the next n ( = batch_size) images from the path list
        and labels and loads the images into them into memory
        """
        # Get next batch of image (path) and labels
        paths = self.images[self.pointer:self.pointer + batch_size]

        # update pointer
        self.pointer += batch_size

        # Read images
        images = np.ndarray([batch_size, self.scale_size[0], self.scale_size[1], 4])

        for i in range(len(paths)):
            img = cv2.imread(paths[i], -1)


            m = np.zeros([1, 1, 1, 1])
            if img.shape==(4,64,4):
                img = np.insert(img, 0, values=m, axis=0)

            # flip image at random if flag is selected
            if self.horizontal_flip and np.random.random() < 0.5:
                img = cv2.flip(img, 1)

            # rescale image
            # img = cv2.resize(img, (self.scale_size[0], self.scale_size[1]))
            img = img.astype(np.float32)

            # subtract mean
            img -= self.mean

            images[i] = img
        # return array of images
        return images
