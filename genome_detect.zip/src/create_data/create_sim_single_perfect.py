import os
import pysam
import random

chroms = ["chr1", "chr2", "chr3", "chr4", "chr5", "chr6", "chr7", "chr8", "chr9", "chr10", "chr11", "chr12", "chr13",
          "chr14", "chr15", "chr16", "chr17", "chr18", "chr19", "chr20", "chr21", "chr22", 'chrX']

sv_max_size = 50
image_length = 64
tot_var_num = 7000
coverage = 5

# # need to change
ref_file = pysam.FastaFile('/mnt/e/project/CCSVar/dataset/GRCh38/GRCh38_chr1-x.fa')
# SV_type_list = ["REF", "SNP", "INS", "DEL", "INV", "DUP", "invDUP"]
sv_type = "SNP"
out_file = '/mnt/e/data/visor_data/input/sim_{0}_train.txt'.format(sv_type)


# for sv_type in SV_type_list:
#     ref_file = pysam.FastaFile('/mnt/e/project/CCSVar/dataset/GRCh38/GRCh38_chr1-x.fa')
#     out_file = '/mnt/e/project/CCSVar/dataset/var_data/perfect_50/test/sim_{0}.txt'.format(sv_type)
#     print("{0} finished!".format(sv_type))


# #

def get_reversed_seq(seq):
    inv_seq = ""
    for i in range(len(seq) - 1, -1, -1):
        bp = seq[i]
        inv_bp = ''
        if bp == 'A':
            inv_bp = 'T'
        elif bp == 'T':
            inv_bp = 'A'
        elif bp == 'C':
            inv_bp = 'G'
        elif bp == 'G':
            inv_bp = 'C'
        else:
            inv_bp = 'N'

        inv_seq += inv_bp
    return inv_seq


with open(out_file, 'w') as fout:
    var_num = 0

    while True:
        if var_num > tot_var_num:
            break
        print(var_num)
        chr = random.choice(chroms)
        chr_length = ref_file.get_reference_length(chr)

        if sv_type == 'REF':

            while True:
                ref_start = random.randint(1, chr_length - image_length)
                ref_end = ref_start + image_length
                ref_seq = ref_file.fetch(chr, ref_start, ref_end)

                if 'N' not in ref_seq:
                    break
            fout.write('> REF {0} N-N\n'.format(ref_start))
            fout.write(ref_seq + '\n')
            for i in range(coverage):
                fout.write(ref_seq + '\n')
            var_num += 1
#此处需要修改 直接修改为SNP ref_origin_bp->A
        elif sv_type == 'SNP':
            var_length = 1

            while True:
                var_start = random.randint(1, chr_length - var_length)
                var_end = var_start + var_length

                left_expand = int((image_length - var_length) / 2)
                ref_start = var_start - left_expand
                ref_end = ref_start + image_length
                ref_seq = ref_file.fetch(chr, ref_start, ref_end)

                if 'N' not in ref_seq:
                    break

            ref_origin_bp = ref_seq[var_start - ref_start]
            while True:
                #alt_snp_bp = 'A'
                alt_snp_bp = random.choice(['A', 'T', 'C', "G"])
                if alt_snp_bp is not ref_origin_bp: # 保证两个不一样
                    break

            read_seq = ref_seq[0: var_start - ref_start] + alt_snp_bp + ref_seq[var_end - ref_start:]

            fout.write('> SNP {0} {1}-{2}\n'.format(var_start - ref_start, ref_origin_bp, alt_snp_bp))
            fout.write(ref_seq + '\n')
            for i in range(coverage):
                fout.write(read_seq + '\n')

            var_num += 1

        elif sv_type == 'DEL':
            var_length = random.randint(1, sv_max_size)

            while True:
                var_start = random.randint(1, chr_length - var_length)
                var_end = var_start + var_length

                left_expand = int((image_length - var_length) / 2)
                ref_start = var_start - left_expand
                ref_end = ref_start + image_length

                ref_seq = ref_file.fetch(chr, ref_start, ref_end)

                if 'N' not in ref_seq:
                    break

            read_seq = ref_seq[0: var_start - ref_start] + '-' * var_length + ref_seq[var_end - ref_start:]

            del_seq = ref_seq[var_start - ref_start: var_end - ref_start]

            fout.write('> DEL {0} {1}-N\n'.format(var_start - ref_start, del_seq))
            fout.write(ref_seq + '\n')
            for i in range(coverage):
                print(i)
                fout.write(read_seq + '\n')
            var_num += 1

        elif sv_type == 'INS':
            ins_length = random.randint(1, sv_max_size)
            var_length = 0
            while True:
                var_start = random.randint(1, chr_length - var_length)
                var_end = var_start

                left_expand = int((image_length - ins_length) / 2)
                ref_start = var_start - left_expand
                ref_end = ref_start + (image_length - ins_length)

                ref_seq = ref_file.fetch(chr, ref_start, ref_end)

                if 'N' not in ref_seq:
                    break

            ins_seq = ""
            for i in range(ins_length):
                ins_seq += random.choice(['A', 'T', 'C', "G"])

            expand_ref_seq = ref_seq[0: var_start - ref_start] + '-' * ins_length + ref_seq[var_end - ref_start:]
            read_seq = ref_seq[0: var_start - ref_start] + ins_seq + ref_seq[var_end - ref_start:]

            fout.write('> INS {0} N-{1}\n'.format(var_start - ref_start, ins_seq))
            fout.write(expand_ref_seq + '\n')
            for i in range(coverage):
                fout.write(read_seq + '\n')
            var_num += 1

        elif sv_type == 'INV':
            var_length = random.randint(1, sv_max_size)
            while True:
                var_start = random.randint(1, chr_length - var_length)
                var_end = var_start + var_length

                left_expand = int((image_length - var_length) / 2)
                ref_start = var_start - left_expand
                ref_end = ref_start + image_length

                ref_seq = ref_file.fetch(chr, ref_start, ref_end)

                if 'N' not in ref_seq:
                    break

            original_seq = ref_seq[var_start - ref_start: var_end - ref_start]
            inv_seq = get_reversed_seq(original_seq)

            read_seq = ref_seq[0: var_start - ref_start] + inv_seq + ref_seq[var_end - ref_start:]

            fout.write('> INV {0} {1}-{2}\n'.format(var_start - ref_start, original_seq, inv_seq))
            fout.write(ref_seq + '\n')
            for i in range(coverage):
                fout.write(read_seq + '\n')
            var_num += 1

        elif sv_type == 'DUP':
            var_length = random.randint(1, sv_max_size)

            while True:
                var_start = random.randint(1, chr_length - var_length)
                var_end = var_start + var_length

                left_expand = int((image_length - var_length * 2) / 2)
                ref_start = var_start - left_expand
                ref_end = ref_start + (image_length - var_length)

                ref_seq = ref_file.fetch(chr, ref_start, ref_end)

                if 'N' not in ref_seq:
                    break

            dup_seq = ref_seq[var_start - ref_start: var_end - ref_start]

            expand_ref_seq = ref_seq[0: var_start - ref_start] + dup_seq + '-' * var_length + ref_seq[
                                                                                              var_end - ref_start:]
            read_seq = ref_seq[0: var_start - ref_start] + dup_seq + dup_seq + ref_seq[var_end - ref_start:]

            fout.write('> DUP {0} N-{1}\n'.format(var_start + var_length - ref_start, dup_seq))
            fout.write(expand_ref_seq + '\n')
            for i in range(coverage):
                fout.write(read_seq + '\n')
            var_num += 1

        elif sv_type == 'invDUP':
            var_length = random.randint(1, sv_max_size)

            while True:
                var_start = random.randint(1, chr_length - var_length)
                var_end = var_start + var_length

                left_expand = int((image_length - var_length * 2) / 2)
                ref_start = var_start - left_expand
                ref_end = ref_start + (image_length - var_length)

                ref_seq = ref_file.fetch(chr, ref_start, ref_end)

                if 'N' not in ref_seq:
                    break

            dup_seq = ref_seq[var_start - ref_start: var_end - ref_start]
            inv_dup_seq = get_reversed_seq(dup_seq)

            read_seq = ref_seq[0: var_start - ref_start] + dup_seq + inv_dup_seq + ref_seq[var_end - ref_start:]
            expand_ref_seq = ref_seq[0: var_start - ref_start] + dup_seq + '-' * var_length + ref_seq[
                                                                                              var_end - ref_start:]

            fout.write('> invDUP {0} N-{1}\n'.format(var_start + var_length - ref_start, dup_seq))
            fout.write(expand_ref_seq + '\n')
            for i in range(coverage):
                fout.write(read_seq + '\n')
            var_num += 1
