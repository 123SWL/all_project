import os
import argparse
import pickle
import numpy as np
import random
import copy


def traversalDir_FirstDir(path):
    tmplist = []
    if (os.path.exists(path)):
        files = os.listdir(path)
        for file1 in files:
            m = os.path.join(path, file1)
            if (os.path.isfile(m)):
                tmplist.append(m)
    return tmplist


def mutate(line, position1, position2):
    tmp = copy.deepcopy(line)
    for i in range(len(line)):
        mut = ['A', 'G', 'T', 'C']
        if np.random.rand() < 0.2:
            if (i > position2 or i < position1):
                try:
                    mut.remove(line[i])
                except:
                    print("Find {} in document".format(line[i]))
                line_list = list(line)
                line_list[i] = random.choice(mut)
                line = ''.join(line_list)
    return line


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='OL Problem Demo Detection & Autorepair')
    parser.add_argument('--input_dir', '-id', default='F:\\sike\\src\\create_data\\data\\txt', help='input txt dirs')
    parser.add_argument('--out_dir', '-od', default='F:\\sike\\src\\create_data\\data\\out0', help='output txt dirs')  #
    args = parser.parse_args()

    # out=mutate("CTCTGTAGTCCTCTGGGTTTGGGTG",4,7)
    deep = 11
    if not os.path.exists(args.out_dir):
        os.makedirs(args.out_dir)

    file_list = traversalDir_FirstDir(args.input_dir)
    for files in file_list:
        if '.txt' not in files:
            continue
            print('skip')

        print("Start {}".format(files))
        out_path = os.path.join(args.out_dir, os.path.split(files)[-1])

        f = open(files, 'r+')
        f_out = open(out_path, 'w+')

        lines = f.read()
        # print(lines)
        content = []
        message = lines.split('>')
        for i in message:
            if "G-C" in i:
                if content != []:
                    for con in content:
                        f_out.write('>' + con)
                        f_out.flush()
                content.append(i + '\n')

        print("End {}".format(files))
