################
# description: add sequencing error into var txt
################
import random
import shutil


def add_snp_error(read, error_rate=0.05):
    read_list = list(read)
    for i in range(len(read_list)):
        num = random.randint(1, 100)
        base = read_list[i]
        if base == "-":
            continue
        if num <= error_rate * 100:
            while True:
                base_alt = random.choice(["A", "C", "G", "T"])
                if base_alt != base:
                    break
            read_list[i] = base_alt
        else:
            continue
    new_read = ''.join(read_list)
    return new_read


def read_var_txt(file_path_read, file_path_write, coverage=10):
    total = []
    with open(file_path_read, "r") as fin:
        cnt = 0
        lines = fin.readlines()
        i = 0
        while i <= len(lines) - coverage:
            cnt += 1
            line = lines[i]
            cur_var_id = line.strip()
            total.append(cur_var_id)
            cur_ref = lines[i + 1].strip()
            total.append(cur_ref)
            for j in range(coverage):
                read = add_snp_error(lines[i + j + 2].strip(), error_rate=0.3)
                total.append(read)
            i += coverage + 2

    # write to txt file
    with open(file_path_write, "w") as fout:
        fout.write(str(total[0]))
        line_num = 1
        while line_num < len(total):
            fout.write("\n" + str(total[line_num]))
            line_num += 1
        fout.close()


def main():
    var_type_list = ["REF", "SNP", "INS", "DEL", "INV", "DUP", "invDUP"]
    for var_type in var_type_list:
        var_txt_file = 'E:/project/CCSVar/dataset/var_data/perfect_50/test/sim_{0}.txt'.format(var_type)
        var_txt_file_snp = 'E:/project/CCSVar/dataset/var_data/error_50/test/sim_{0}.txt'.format(var_type)
        if var_type == "REF":
            shutil.copy(var_txt_file, var_txt_file_snp)
        else:
            read_var_txt(var_txt_file, var_txt_file_snp)
        print("{0} finished!".format(var_type))


if __name__ == "__main__":
    main()
