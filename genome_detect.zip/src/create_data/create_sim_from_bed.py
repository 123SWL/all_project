# #!/usr/bin/env python
# # -*- coding: UTF-8 -*-
# """======================================================================================================
# # Project: CCS_VAR
# # Script :create_sim_from_bed.py
# # Author : zoey
# # Date   : 2021.08.06
# # Description: simulate data and corresponding labels from bed file
# =========================================================================================================="""
# import numpy as np
# import cv2
# import os
# import matplotlib
#
# matplotlib.use('Agg')
# import matplotlib.pyplot as plt
#
# sv_dict = {
#     "insertion": "INS",
#     "deletion": "DEL",
#     "inversion": "INV",
#     "tandem duplication": "tDUP",
#     "inverted tandem duplication": "invDUP"
# }
#
# def read_bed(bed_file, sv_dict):
#     '''
#
#     :param bed_file:
#     :return:
#     '''
#
#     start_coord = []
#     end_coord = []
#     chrom = []
#     sv_type = []
#     sv_length = []
#     bkps = []
#
#     with open(bed_file, "r") as fin:
#         lines = fin.readlines()
#         for line in lines:
#             line_split = line.strip().split("\t")
#             this_str = line_split[4]
#             print(this_str)
#             if "A" in this_str:
#                 this_len = len(this_str)
#             else:
#                 this_len = int(line_split[2])-int(line_split[1])
#
#             if sv_dict[line_split[3]] in ['INS', 'DEL', 'tDUP', 'INV']:
#                 chrom.append(line_split[0])
#                 start_coord.append(line_split[1])
#                 end_coord.append(line_split[2])
#                 sv_type.append(sv_dict[line_split[3]])
#                 sv_length.append(this_len)
#                 bkps.append(line_split[4])
#             else:
#                 continue
#     return chrom, start_coord, end_coord, sv_type, sv_length, bkps
#
# bed_path = "E:\\data\\visor_data\\input\\HACk.valid.bed"
# chrom, start_coord, end_coord, sv_type, sv_length, bkps = read_bed(bed_path,sv_dict)
import os
from multiprocessing import Pool
import time


def func(i):  # 返回值只有进程池才有,父子进程没有返回值
    time.sleep(1)
    # return i * i * i

    print(i, os.getpid())
    return i


if __name__ == '__main__':
    p = Pool(processes=4)
    # res_l = []  # 从异步提交任务获取结果
    for i in range(10000):
        print("111:", os.getpid())
        # res = p.apply(func,args=(i,)) #apply的结果就是func的返回值,同步提交
        # print(res)

        res = p.apply_async(func, args=(i,))  # apply_sync的结果就是异步获取func的返回值
        # res_l.append(res)  # 从异步提交任务获取结果
    # multiple_results = [p.apply_async(os.getpid, ()) for i in range(400)]
    # print([res.get(timeout=1) for res in multiple_results])

    #######################
    p.close()  # 关闭进程池
    p.join()  # 主进程等待所有进程执行完毕
    #######################

    # 在close，join之后再使用get方法，
    # for res in range(len(res_l)):
    #     print(res_l[res].get())  # 等着func的计算结果
