#!/usr/bin/env python
# -*- coding: UTF-8 -*-
"""======================================================================================================
# Project: CCS_VAR
# Script :create_sim_from_vcf.py
# Description: simulate data and corresponding labels from vcf file
=========================================================================================================="""
import numpy as np
import cv2
import pysam
import os
import matplotlib
from multiprocessing import Pool
import random
import time

matplotlib.use('Agg')
import matplotlib.pyplot as plt

sv_dict = {
    "insertion": "INS",
    "deletion": "DEL",
    "inversion": "INV",
    "tandem duplication": "tDUP",
    "inverted tandem duplication": "invDUP"
}

fasta_file = "/mnt/e/data/GRCh38_chr1-x.fa"
fasta_open = pysam.FastaFile(fasta_file)


def read_bed(bed_file):
    '''

    :param bed_file:
    :return:
    '''

    start_coord = []
    end_coord = []
    chrom = []
    sv_type = []
    sv_length = []
    bkps = []

    with open(bed_file, "r") as fin:
        lines = fin.readlines()
        for line in lines:
            line_split = line.strip().split("\t")
            this_str = line_split[4]
            if "A" in this_str:
                this_len = len(this_str)
            else:
                this_len = int(line_split[2]) - int(line_split[1])

            if sv_dict[line_split[3]] in ['INS', 'DEL', 'tDUP', 'INV', 'invDUP']:
                chrom.append(line_split[0])
                start_coord.append(line_split[1])
                end_coord.append(line_split[2])
                sv_type.append(sv_dict[line_split[3]])
                sv_length.append(this_len)
                bkps.append(line_split[4])
            else:
                continue
    return chrom, start_coord, end_coord, sv_type, sv_length, bkps


def read_vcf(vcf_file):
    '''

    :param vcf_file:
    :return:
    '''

    start_coord = []
    end_coord = []
    chrom = []
    sv_type = []
    sv_length = []
    bkps = []

    vcf_in = pysam.VariantFile(vcf_file)
    for rec in vcf_in:
        if rec.info['SVTYPE'] in ['INS', 'DEL', 'tDUP', 'INV']:
            chrom.append(rec.chrom)
            start_coord.append(rec.start + 1)
            end_coord.append(rec.stop)
            sv_type.append(rec.info['SVTYPE'])
            sv_length.append(rec.info['SVLEN'])
            bkps.append(rec.info['BKPS'])
            # print(rec.info['SVLEN'])
        else:
            continue
    return chrom, start_coord, end_coord, sv_type, sv_length, bkps


def generate_random_str(str_len):
    seed = "AGCT"
    str1 = []
    for i in range(str_len):
        str1.append(random.choice(seed))
    random_str = ''.join(str1)
    return random_str


def encode_ref_homo(img, start, end, img_start, ref_chr, coverage):
    A = 0
    C = 1
    G = 2
    T = 3

    ref_seq = fasta_open.fetch(ref_chr, start, end + 1)
    if 'N' * len(ref_seq) == ref_seq:
        ref_seq = generate_random_str(len(ref_seq))
    for i in range(len(ref_seq)):
        ref_base = ref_seq[i]
        read_base = ref_seq[i]
        pos_img = img_start + i
        # 开始 encode
        # first channel: ref
        if ref_base == 'A':
            img[A][pos_img][0] = coverage
        elif ref_base == 'C':
            img[C][pos_img][0] = coverage
        elif ref_base == 'G':
            img[G][pos_img][0] = coverage
        elif ref_base == 'T':
            img[T][pos_img][0] = coverage
        else:
            pass

        # second channel: read
        if read_base == 'A':
            img[A][pos_img][1] = coverage
        elif read_base == 'C':
            img[C][pos_img][1] = coverage
        elif read_base == 'G':
            img[G][pos_img][1] = coverage
        elif read_base == 'T':
            img[T][pos_img][1] = coverage
        else:
            pass
    return img


def encode_candidate(img, ref_seq, read_seq, img_start, coverage, sv_type):
    A = 0
    C = 1
    G = 2
    T = 3
    # encode first channel: ref
    for i in range(len(ref_seq)):
        ref_base = ref_seq[i]
        pos_img = img_start + i
        if ref_base == 'A':
            img[A][pos_img][0] = coverage
        elif ref_base == 'C':
            img[C][pos_img][0] = coverage
        elif ref_base == 'G':
            img[G][pos_img][0] = coverage
        elif ref_base == 'T':
            img[T][pos_img][0] = coverage
        else:
            pass

    # encode second channel: read
    for i in range(len(read_seq)):
        read_base = read_seq[i]
        pos_img = img_start + i
        if read_base == 'A':
            img[A][pos_img][1] = coverage
        elif read_base == 'C':
            img[C][pos_img][1] = coverage
        elif read_base == 'G':
            img[G][pos_img][1] = coverage
        elif read_base == 'T':
            img[T][pos_img][1] = coverage
        else:
            pass

    # encode third channel: inv
    if sv_type == 'INV' or sv_type == "invDUP":
        for i in range(len(ref_seq)):
            read_base = read_seq[i]
            pos_img = img_start + i
            if read_base == 'A':
                img[A][pos_img][2] = coverage
            elif read_base == 'C':
                img[C][pos_img][2] = coverage
            elif read_base == 'G':
                img[G][pos_img][2] = coverage
            elif read_base == 'T':
                img[T][pos_img][2] = coverage
            else:
                pass

    # encode forth channel: dup
    if sv_type == 'tDUP' or sv_type == "invDUP":
        for i in range(len(read_seq)):
            read_base = read_seq[i]
            pos_img = img_start + i
            if read_base == 'A':
                img[A][pos_img][3] = coverage
            elif read_base == 'C':
                img[C][pos_img][3] = coverage
            elif read_base == 'G':
                img[G][pos_img][3] = coverage
            elif read_base == 'T':
                img[T][pos_img][3] = coverage
            else:
                pass

    return img


def encode_sampling(image, image_length):
    """
    对于大于64 bp， 图片层面进行采样
    """
    ratio = image.shape[1] / image_length  # 此处可以改变图像的分辨率
    image1 = np.zeros((int(image.shape[0]),
                       int(image.shape[1] / ratio),
                       image.shape[2]), dtype='float32')

    for i in range(image1.shape[0]):
        for j in range(image1.shape[1]):
            for k in range(image1.shape[2]):
                delta = image[i, int(j * ratio), k]
                image1[i, j, k] = delta
    return image1


def encode_img(ref_seq, read_seq, sv_type, coverage, image_len, image_height, channel, var_start, var_end, ref_chr):
    # ref_seq len < imgae_len, encode directly
    if len(ref_seq) <= 0.8 * image_len:
        img = np.zeros((image_height, image_len, channel))
        distance = image_len - len(ref_seq)

        seq_a_start = var_start - (distance // 2)
        seq_a_end = var_start - 1
        seq_b_start = var_end + 1
        seq_b_end = var_end + distance - distance // 2

        img_a_start = 0
        img_b_start = distance // 2 + len(ref_seq)
        img_start = distance // 2  # 有问题区间的开始坐标

        # encode ref homo: 获取问题区间两边的序列 以及 coverage 等信息, 并进行encode
        img = encode_ref_homo(img, seq_a_start, seq_a_end, img_a_start, ref_chr, coverage)
        img = encode_ref_homo(img, seq_b_start, seq_b_end, img_b_start, ref_chr, coverage)

        # encode 问题区间
        img = encode_candidate(img, ref_seq, read_seq, img_start, coverage, sv_type)

        # normalise img
        normalised_img = (img - np.min(img)) / (np.max(img) - np.min(img)) * 255

    # ref_seq len > imgae_len, compress image and encode
    else:
        interval_dis = var_end - var_start + 1
        seq_a_start = var_start - int(0.1 * interval_dis)
        seq_a_end = var_start - 1
        seq_b_start = var_end + 1
        seq_b_end = seq_b_start + int(0.1 * interval_dis) - 1
        img_a_start = 0
        img_b_start = int(0.1 * interval_dis) + interval_dis
        img_start = int(0.1 * interval_dis)  # 有问题区间的开始坐标

        # print("distance：", interval_dis)
        # print("interval start:", var_start, "interval end:", var_end)
        # print("seq_a_start:", seq_a_start, " seq_a_end:", seq_a_end)
        # print("seq_b_start:", seq_b_start, " seq_b_end:", seq_b_end)
        # print("img_a_start:", img_a_start)
        # print("img_b_start:", img_b_start)

        # encode ref homo：问题区间两边取10%的序列, 初始化图片长度为max_len
        max_len = int(interval_dis + 0.2 * interval_dis)
        img_large = np.zeros((image_height, max_len, channel))

        img_large = encode_ref_homo(img_large, seq_a_start, seq_a_end, img_a_start, ref_chr, coverage)
        img_large = encode_ref_homo(img_large, seq_b_start, seq_b_end, img_b_start, ref_chr, coverage)

        # encode 问题区间
        img = encode_candidate(img_large, ref_seq, read_seq, img_start, coverage, sv_type)

        # normalise img
        normalised_img = (img - np.min(img)) / (np.max(img) - np.min(img)) * 255

        # sampling 压缩图片
        normalised_img = encode_sampling(normalised_img, image_len)
    return normalised_img


def acuqire_info(input_file, is_vcf, coverage=5, image_len=64, image_height=5, channel=4):
    if is_vcf:
        chrom, start_coord, end_coord, sv_type, sv_length, bkps = read_vcf(input_file)
    else:
        chrom, start_coord, end_coord, sv_type, sv_length, bkps = read_bed(input_file)
    p = Pool(processes=4)
    res_l = []
    label = []
    count = 0
    for i in range(len(chrom)):
        if int(end_coord[i]) - int(start_coord[i]) > 2000:
            continue
        if sv_type[i] == 'INS':
            read_seq = ''.join(bkps[i])
            if is_vcf:
                read_seq = read_seq[:-1]
            ref_seq = 'N' * len(read_seq)
            var_start = int(start_coord[i])
            var_end = var_start + len(ref_seq)
        elif sv_type[i] == 'DEL':
            count += 1
            ref_seq = fasta_open.fetch(chrom[i], int(start_coord[i]), int(end_coord[i]))
            if 'N' * len(ref_seq) == ref_seq:
                continue
            else:
                read_seq = 'N' * len(ref_seq)
                var_start = int(start_coord[i])
                var_end = int(end_coord[i])
        elif sv_type[i] == 'INV':
            ref_seq = fasta_open.fetch(chrom[i], int(start_coord[i]), int(end_coord[i]))
            if 'N' * len(ref_seq) == ref_seq:
                continue
            else:
                read_seq = ref_seq[:]
                var_start = int(start_coord[i])
                var_end = int(end_coord[i])
        elif sv_type[i] == 'tDUP':
            read_seq = fasta_open.fetch(chrom[i], int(start_coord[i]), int(end_coord[i]))
            if 'N' * len(read_seq) == read_seq:
                continue
            else:
                ref_seq = 'N' * len(read_seq)
                var_start = int(start_coord[i])
                var_end = int(end_coord[i])
        elif sv_type[i] == "invDUP":
            read_seq = fasta_open.fetch(chrom[i], int(start_coord[i]), int(end_coord[i]))
            if 'N' * len(read_seq) == read_seq:
                continue
            else:
                ref_seq = 'N' * len(read_seq)
                var_start = int(start_coord[i])
                var_end = int(end_coord[i])
        else:
            continue

        # normalised_img = encode_img(ref_seq, read_seq, sv_type[i], coverage, image_len, image_height, channel,
        #                             var_start, var_end, chrom[i], fasta_open)

        normalised_img = p.apply_async(encode_img, args=(ref_seq, read_seq, sv_type[i], coverage, image_len,
                                                         image_height, channel, var_start, var_end, chrom[i]))
        # print("sv type 2:", sv_type[i])
        res_l.append(normalised_img)
        label.append(sv_type[i])
    p.close()
    p.join()
    return res_l, label


def write_pic(out_file, images, labels):
    for i in range(len(images)):
        if i % 100 == 0:
            print("finished {0}".format(i))
        this_img = images[i].get()
        cv2.imwrite(os.path.join(out_file, '{0}_{1}.png'.format(i, labels[i])), this_img)

        if i < 100:
            # plot for show
            plt.subplot(411)
            plt.imshow(this_img[:, :, 0])
            plt.yticks([])

            plt.subplot(412)
            plt.imshow(this_img[:, :, 1])
            plt.yticks([])

            plt.subplot(413)
            plt.imshow(this_img[:, :, 2])
            plt.yticks([])

            plt.subplot(414)
            plt.imshow(this_img[:, :, 3])
            plt.yticks([])
            plt.savefig(os.path.join(out_file, '{0}_{1}_show.png'.format(i, labels[i])))


def main():
    start_time = time.time()

    # paths
    # vcf_input = "/mnt/e/data/chr20/output/encode_csvtools/picture_from_csvtools/vcf/sim_clone0.benchmark.vcf"
    bed_input = "/mnt/e/data/visor_data/input/HACk.valid2.bed"

    # out_path = "/mnt/e/data/chr20/output/encode_csvtools/picture_from_csvtools/pic/train/"
    out_path = "/mnt/e/data/visor_data/train_data/valid2_true_old/"

    # encode into image
    images, labels = acuqire_info(bed_input, False, 5, 64, 5, 4)
    # image save
    write_pic(out_path, images, labels)

    end_time = time.time()
    print("Cost time: {0}".format(end_time - start_time))


if __name__ == "__main__":

    main()
