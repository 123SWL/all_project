from collections import Counter
import shutil
import os

# 统计图片数量与类型
train_file = "E:\\data\\visor_data\\train_data\\valid2.txt"
valid_file = "E:\\data\\chr20\\output\\encode_csvtools\\picture\\valid.txt"
train_file2 = "E:\\data\\chr20\\output\\encode_csvtools\\picture_from_csvtools\\pic\\train.txt"
with open(train_file) as f:
    lines = f.readlines()
    images = []
    labels = []
    count = 0
    for line in lines:
        items = line.split()
        if items[0].endswith('_DUP.png'):
            count += 1
        images.append(items[0])
        labels.append(int(items[1]))

lab = Counter(labels)
print(dict(lab))


# 删除指定名字的图片
# import os
# train_image = "E:\\data\\chr20\\output\\encode_csvtools\\picture\\train\\"
# for root, dirs, files in os.walk(train_image):
#     for name in files:
#         if '_DUP.png' in name:
#             os.remove(os.path.join(root, name))
#             print("Delete File: " + os.path.join(root, name))

# 复制图片到指定文件夹

# src_dir = 'E:\\data\\chr20\\output\\encode_csvtools\\picture\\train\\'
# dst_dir = 'E:\\data\\chr20\\output\\encode_csvtools\\picture_from_csvtools\\pic\\train\\'
# count = 0
# for root, dirs, files in os.walk(src_dir, True):
#     for filename in files:
#         if "SNP" in filename or "invDUP" in filename:
#             count += 1
#             shutil.copy(os.path.join(root, filename), dst_dir)
#         else:
#             continue
#         print(count)
