import os
import matplotlib

matplotlib.use('Agg')
import numpy as np
import cv2 as cv
import matplotlib.pyplot as plt


def plot_coding_4c(ref, reads, var_type, var_start, var_len, var_id, out_path):
    A = 0
    C = 1
    G = 2
    T = 3
    possible_bps = ['A', 'C', 'G', 'T']

    coverage = len(reads)
    img = np.zeros((img_height, img_length, 4))

    # # first channel, ref channel
    for i in range(len(ref)):
        if ref[i] == 'A':
            img[A][i][0] = coverage
        elif ref[i] == 'C':
            img[C][i][0] = coverage
        elif ref[i] == 'G':
            img[G][i][0] = coverage
        elif ref[i] == 'T':
            img[T][i][0] = coverage
        else:
            pass

    # # second channel, read channel
    for read in reads:
        for i in range(len(read)):
            if read[i] == 'A':
                img[A][i][1] = coverage
            elif read[i] == 'C':
                img[C][i][1] = coverage
            elif read[i] == 'G':
                img[G][i][1] = coverage
            elif read[i] == 'T':
                img[T][i][1] = coverage
            else:
                pass

    # # third channel, inv channel
    if var_type == 'INV' or var_type == 'invDUP':
        for read in reads:
            for i in range(var_start, var_start + var_len):
                if read[i] == 'A':
                    img[A][i][2] = coverage
                elif read[i] == 'C':
                    img[C][i][2] = coverage
                elif read[i] == 'G':
                    img[G][i][2] = coverage
                elif read[i] == 'T':
                    img[T][i][2] = coverage
                else:
                    pass

    # # fourth channel, dup channel
    if var_type == 'DUP' or var_type == 'invDUP':
        for read in reads:

            for i in range(var_start, var_start + var_len):
                if read[i] == 'A':
                    img[A][i][3] = coverage
                elif read[i] == 'C':
                    img[C][i][3] = coverage
                elif read[i] == 'G':
                    img[G][i][3] = coverage
                elif read[i] == 'T':
                    img[T][i][3] = coverage
                else:
                    pass

    # normalise img
    normalised_img = (img - np.min(img)) / (np.max(img) - np.min(img)) * 255
    #
    # for i in range(4):
    #     for j in range(img_height):
    #         for k in range(img_length):
    #             print(str(int(normalised_img[j, k, i])) + '\t', end='')
    #         print()

    # plt.show()
    cv.imwrite(os.path.join(out_path, '{0}.png'.format(var_id)), normalised_img)

    if cnt < 10:
        plt.subplot(411)
        plt.imshow(normalised_img[:, :, 0])
        plt.yticks([])

        plt.subplot(412)
        plt.imshow(normalised_img[:, :, 1])
        plt.yticks([])

        plt.subplot(413)
        plt.imshow(normalised_img[:, :, 2])
        plt.yticks([])

        plt.subplot(414)
        plt.imshow(normalised_img[:, :, 3])
        plt.yticks([])
        plt.savefig(os.path.join(out_path, '{0}_show.png'.format(var_id)))


if __name__ == '__main__':

    var_num = 0
    coverage = 10

    img_length = 64
    img_height = 4

    count = 0
    total_count = 100

    # # need to change
    #var_type_list = ["REF", "SNP", "INS", "DEL", "INV", "DUP", "invDUP"]
    var_type_list = ["SNP"]
    out_path = '/mnt/e/data/visor_data/train_data/valid_snp/'
    for var_type in var_type_list:
        var_txt_file = '/mnt/e/data/var_data/perfect/test/sim_{0}.txt'.format(var_type)
        #var_txt_file = '/mnt/e/data/visor_data/input/sim_snp_ac.txt'.format(var_type)


        with open(var_txt_file) as fin:
            cur_var_id = '0'
            cnt = 0
            lines = fin.readlines()
            i = 0
            while i <= len(lines) - coverage:

                cnt += 1

                line = lines[i]
                # meet a new event

                line_split = line.strip().split(' ')
                cur_var_id = str(var_num) + '_' + line_split[1]
                var_start = int(line_split[2])
                var_len = max(len(line_split[3].split('-')[0]), len(line_split[3].split('-')[1]))

                var_num += 1

                print(var_num)
                print(count)
                # parse ref and reads
                ref = lines[i + 1].strip()

                reads = []
                for j in range(coverage):
                    reads.append(lines[i + j + 2].strip())

                i += coverage + 2

                error_event_flat = 0
                if len(ref) != img_length:
                    error_event_flat = 1
                for read in reads:
                    if len(read) != img_length:
                        error_event_flat = 1
                if error_event_flat == 1:
                    continue
                else:
                    count += 1
                    plot_coding_4c(ref, reads, var_type, var_start, var_len, cur_var_id, out_path)
                if count > total_count:
                    break

            # print('\n\n')
            # print(cur_var_id)
            # print(ref)
            # print(reads)
            # print(len(reads))
        print("{0} finished!".format(var_type))
