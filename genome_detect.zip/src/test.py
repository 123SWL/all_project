# utf-8
import pysam
from mpileup_pro.tag_collect_2 import tag_collect_all
from coding.code_real_single_4c import parse_cluster_intervals
from mpileup_pro.tag_cluster_2 import *


def main():
    options = {
        "min_quality": 10,
        "segment_overlap_tolerance": 2,
        "segment_gap_tolerance": 2,
        "max_sv_size": 10000,
        "min_sv_size": 0,
        "ref_id": "chr20",
        "start": 57963600,
        "end": 57978000

    }
    # test:chr20-278932-279168,chr20-61564-63735,chr20-1301629-1302637,chr20-44677206-44683572,chr20-47670651-47670736
    # chr1-81194666-81195870, chr20-61564-63735, chr20-44677206-44683269,chr20-57974846-57975133
    # bam_file = "/mnt/e/data/chr20/HG00733.pbmm2_sorted.chr20.bam"
    bam_file = "/mnt/e/data/HG00733.ngmlr.srt.bam"
    fasta_file = "/mnt/e/data/GRCh38/GRCh38_chr1-x.fa"
    bam = pysam.AlignmentFile(bam_file, "rb")
    fasta_open = pysam.FastaFile(fasta_file)
    tag_all_sigs = tag_collect_all(bam, fasta_open, options)

    # for pos, tags in tag_all_sigs.items():
    #     for i in range(len(tags)):
    #         if tags[i][0].tag_type == "ref_hete" and tags[i][0].pos == 44679958:
    #             print(tags[i][0].to_string())

    # 得到新的tag
    new_tag_dict = preprocess_new_tag(tag_all_sigs_dict=tag_all_sigs)
    # 找出cluster信息
    record_intervals = cluster_interval(type_dict_all=new_tag_dict)
    # # encode into 4 channels
    # out_path = '/mnt/e/data/chr20/output/encode_4c/test/dup/image'
    # parse_cluster_intervals(record_intervals, 64, 4, fasta_open, out_path=out_path)


if __name__ == "__main__":
    main()
